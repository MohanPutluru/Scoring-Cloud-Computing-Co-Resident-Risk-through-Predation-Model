/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package zerotrust1;

import java.util.List;
import org.cloudbus.cloudsim.power.*;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.VmStateHistoryEntry;
import org.cloudbus.cloudsim.util.ExecutionTimeMeasurer;


/**
 
 */
public class ZeroTrustVmSelectionPolicy2 extends PowerVmSelectionPolicy {
	/* (non-Javadoc)
	 * @see
	 * org.cloudbus.cloudsim.experiments.power.PowerVmSelectionPolicy#getVmsToMigrate(org.cloudbus
	 * .cloudsim.power.PowerHost) */
	@Override
	public Vm getVmToMigrate(PowerHost host) {
		List<PowerVm> migratableVms = getMigratableVms(host);
		if (migratableVms.isEmpty()) {
			return null;
		}
		Vm vmToMigrate = null;
		Vm vm1 = null;
		double thisTime = 0;
		for (Vm vm : migratableVms) {
			if (vm.isInMigration()) {
				continue;
			}
			//double metric = vm.getTotalUtilizationOfCpuMips(CloudSim.clock()) / vm.getMips();
			if (!vm.isInMigration()) {
				if (!vm.getStateHistory().isEmpty()) {
					int i=2;
					VmStateHistoryEntry curState = vm.getStateHistory().get(vm.getStateHistory().size()-1);
					while(i<vm.getStateHistory().size()-1) {
						VmStateHistoryEntry previousState = vm.getStateHistory().get(vm.getStateHistory().size() - i);
					if (previousState.isInMigration()==true) {
						System.out.println("vm " +vm.getId() + " on host " + vm.getHost().getId() +" migrated "+ previousState.isInMigration()+" since : "+ (curState.getTime()-previousState.getTime()) +" secs ago.");
						if (curState.getTime()-previousState.getTime()>ZeroTrustConstants.SCHEDULING_INTERVAL*2) {
							thisTime = curState.getTime()-previousState.getTime();
							vm1 = vm;
						}
						break;
					}
					//System.out.println(vm.getId());//System.out.println(previousState.getTime());
					//System.out.println(previousState.isInMigration());//System.out.println(curState.getTime());
				i++;
				}}
				vmToMigrate = vm1;
			}
		}
		return vmToMigrate;
	}

}
