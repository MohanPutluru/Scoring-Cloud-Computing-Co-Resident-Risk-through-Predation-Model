/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package gametheory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.HostDynamicWorkload;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.util.ExecutionTimeMeasurer;
import org.cloudbus.cloudsim.util.MathUtil;

import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationAbstract;
import org.cloudbus.cloudsim.power.PowerVmSelectionPolicy;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.power.PowerHostUtilizationHistory;

import predprey.Location;

/**

 */
public class GameTheoryPowerVmAllocationPolicyMigration extends
		PowerVmAllocationPolicyMigrationAbstract {

	/** The safety parameter. */
	private double safetyParameter = 0;

	/** The fallback vm allocation policy. */
	private PowerVmAllocationPolicyMigrationAbstract fallbackVmAllocationPolicy;

	/**
	 * Instantiates a new power vm allocation policy migration mad.
	 * 
	 * @param hostList the host list
	 * @param vmSelectionPolicy the vm selection policy
	 * @param safetyParameter the safety parameter
	 * @param utilizationThreshold the utilization threshold
	 */
	public GameTheoryPowerVmAllocationPolicyMigration(
			List<? extends Host> hostList,
			PowerVmSelectionPolicy vmSelectionPolicy,
			double safetyParameter,
			PowerVmAllocationPolicyMigrationAbstract fallbackVmAllocationPolicy,
			double utilizationThreshold) {
		super(hostList, vmSelectionPolicy);
		setSafetyParameter(safetyParameter);
		setFallbackVmAllocationPolicy(fallbackVmAllocationPolicy);
	}

	/**
	 * Instantiates a new power vm allocation policy migration.
	 * 
	 * @param hostList the host list
	 * @param vmSelectionPolicy the vm selection policy
	 * @param safetyParameter the safety parameter
	 */
	public GameTheoryPowerVmAllocationPolicyMigration(
			List<? extends Host> hostList,
			PowerVmSelectionPolicy vmSelectionPolicy,
			double safetyParameter,
			PowerVmAllocationPolicyMigrationAbstract fallbackVmAllocationPolicy) {
		super(hostList, vmSelectionPolicy);
		setSafetyParameter(safetyParameter);
		setFallbackVmAllocationPolicy(fallbackVmAllocationPolicy);
	}



	/**
	 * Gets the host utilization iqr.
	 * 
	 * @param host the host
	 * @return the host utilization iqr
	 */
	protected double getHostUtilizationIqr(PowerHostUtilizationHistory host) throws IllegalArgumentException {
		double[] data = host.getUtilizationHistory();
		if (MathUtil.countNonZeroBeginning(data) >= 12) { // 12 has been suggested as a safe value
			return MathUtil.iqr(data);
		}
		throw new IllegalArgumentException();
	}

	/**
	 * Sets the safety parameter.
	 * 
	 * @param safetyParameter the new safety parameter
	 */
	protected void setSafetyParameter(double safetyParameter) {
		if (safetyParameter < 0) {
			Log.printLine("The safety parameter cannot be less than zero. The passed value is: "
					+ safetyParameter);
			System.exit(0);
		}
		this.safetyParameter = safetyParameter;
	}

	/**
	 * Gets the safety parameter.
	 * 
	 * @return the safety parameter
	 */
	protected double getSafetyParameter() {
		return safetyParameter;
	}

	/**
	 * Sets the fallback vm allocation policy.
	 * 
	 * @param fallbackVmAllocationPolicy the new fallback vm allocation policy
	 */
	public void setFallbackVmAllocationPolicy(
			PowerVmAllocationPolicyMigrationAbstract fallbackVmAllocationPolicy) {
		this.fallbackVmAllocationPolicy = fallbackVmAllocationPolicy;
	}

	/**
	 * Gets the fallback vm allocation policy.
	 * 
	 * @return the fallback vm allocation policy
	 */
	public PowerVmAllocationPolicyMigrationAbstract getFallbackVmAllocationPolicy() {
		return fallbackVmAllocationPolicy;
	}
	
	/**
	 * Find host for vm.
	 * 
	 * @param vm the vm
	 * @return the power host
	 */
	@Override
	public PowerHost findHostForVm(Vm vm) {
		Set<PowerHost> excludedHosts = new HashSet<PowerHost>();
		if (vm.getHost() != null) {
			System.out.println("The excluded host is: " + excludedHosts);
			excludedHosts.add((PowerHost) vm.getHost());
		}
		return findHostForVm(vm, excludedHosts);
	}
	/**
	 * Find host for vm.
	 * 
	 * @param vm the vm
	 * @param excludedHosts the excluded hosts
	 * @return the power host
	 */
	@Override
	public PowerHost findHostForVm(Vm vm, Set<? extends Host> excludedHosts) {
//		System.out.println("[findHostForVm(vm, excludedHosts)] Press enter to continue");
//		try{System.in.read();}
//        catch(Exception e){}
		PowerHost allocatedHost = null;
		double minPower = Double.MAX_VALUE;
		int hostNum = -1;
		int hostRow = 777;
		int hostColIdx = 777;
		// Code to import the map of the vm to its location. 
		List<Map<String, Object>> vmIdToPeLocList = GameTheoryRunner.getDatacenter().getVmToPeLocList();
		// Code to find the location that matches the vm to the location

		//A search for the vm in the vmToAnimalLocation list
		for(Map<String, Object> vmToAnimalLoc: vmIdToPeLocList ) {
			Location loc = (Location) vmToAnimalLoc.get("animal");
			if((int) vmToAnimalLoc.get("vm") == vm.getId()) {
		//This code will calculate the host id from the animal location
		//int HostNumber= Math.floorMod(loc.getRow(), 2)*2+Math.floorMod(loc.getCol(), 2);
				hostRow = (int)	Math.floor(loc.getRow()/ 2);
				int hostRowIdx = hostRow *100;
				hostColIdx = loc.getCol()/2;
				hostNum = hostRowIdx + hostColIdx;
			}//end if
		}// end for
		for(PowerHost host : this.<PowerHost> getHostList()) {
			if(host.getId()==hostNum) {
				if (host.isSuitableForVm(vm)) {
//					System.out.println("[findHostForVm(vm, excludedHosts)] The host is suitable Press enter to continue");
//					try{System.in.read();}
//			        catch(Exception e){}
				if (getUtilizationOfCpuMips(host) != 0 && isHostOverUtilizedAfterAllocation(host, vm)) {
					continue;
				}
				try {
					if(host.getVmList().size()-host.getVmScheduler().getVmsMigratingOut().size() > host.getPeList().size()) {
//						System.out.println("[findHostForVm] Press enter to continue");
//						System.out.println("The projected number of vms in the host are: " + (host.getVmList().size()-host.getVmScheduler().getVmsMigratingOut().size()));
//						try{System.in.read();}
//				        catch(Exception e){}
						double powerAfterAllocation = getPowerAfterAllocation(host, vm);	
					if (powerAfterAllocation != -1) {
						double powerDiff = powerAfterAllocation - host.getPower();
						if (powerDiff < minPower) {
							minPower = powerDiff;
							allocatedHost = host;
						} //end if
					} //end if
					} else {
						double powerDiff =  0;
						if (powerDiff < minPower) {
							minPower = powerDiff;
							allocatedHost = host;
					}//end if
					}//end else
				} //end try
				catch (Exception e) {}
				}// end is suitable
				}//end if host is searched for host
			}// end for hostlist
if(allocatedHost == null) {
	System.out.println("[findHostForVm without host for vm: "+ vm.getId() + " calculated row:" + hostRow + " and column " + hostColIdx);
} 
		return allocatedHost;
	}
	
	/**
	 * Optimize allocation of the VMs according to the migration map.
	 * 
	 * @param vmList the vm list
	 * 
	 * @return the array list< hash map< string, object>>
	 */
	
	@Override
	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) {
		PowerHost allocatedHost = null;
		List<Map<String, Object>> migrationMap = new LinkedList<Map<String, Object>>();
		int hostNum = -1;
		ExecutionTimeMeasurer.start("optimizeAllocationTotal");

		ExecutionTimeMeasurer.start("optimizeAllocationHostSelection");
		List<PowerHostUtilizationHistory> overUtilizedHosts = getOverUtilizedHosts();
		
		printOverUtilizedHosts(overUtilizedHosts);

		ExecutionTimeMeasurer.start("optimizeAllocationVmSelection");
		List<Map<String, Object>> vmToMovedAnimalLocList = GameTheoryRunner.getTranslator().getVmIdToMovedAnimalLocList();
		getExecutionTimeHistoryVmSelection().add(ExecutionTimeMeasurer.end("optimizeAllocationVmSelection"));

		for(Map<String, Object> vmToMovedAnimalLoc: vmToMovedAnimalLocList ) {
			for(Vm vm: vmList ) {
			if( vm.getId()== (int)vmToMovedAnimalLoc.get("vm") ) {	//if the vm on the vmList matches an entry on vmIdToAnimalLocList
				Location loc = (Location) vmToMovedAnimalLoc.get("animal");
  				int hostRow = (int)	Math.floor(loc.getRow()/ 2);
				int hostRowIdx = hostRow *100;
				int hostColIdx = loc.getCol()/2;
				hostNum = hostRowIdx + hostColIdx;
				for(PowerHost host : this.<PowerHost> getHostList()) {
					if(host.getId()==hostNum) {
						allocatedHost = host;
					}//end if
				}// end for
			Map<String, Object> migrate = new HashMap<String, Object>();
			migrate.put("vm", vm);
			migrate.put("host", allocatedHost);
			migrationMap.add(migrate);
			}//end if
			}// end for
		}//end for
		getExecutionTimeHistoryHostSelection().add(ExecutionTimeMeasurer.end("optimizeAllocationHostSelection"));
		
		Log.printLine();

		getExecutionTimeHistoryTotal().add(ExecutionTimeMeasurer.end("optimizeAllocationTotal"));

		return migrationMap;
	}
//	@Override
//	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) {
//		PowerHost allocatedHost = null;
//		ExecutionTimeMeasurer.start("optimizeAllocationTotal");
//		ExecutionTimeMeasurer.start("optimizeAllocationHostSelection");
//		List<Map<String, Object>> migrationMap = new LinkedList<Map<String, Object>>();
//		double minPower = Double.MAX_VALUE;
//		int hostNum = -1;
//		// Code to import the map of the vm to the location it is going to.
//		List<Map<String, Object>> vmToMovedAnimalLocList = PredationRunner.getTranslator().getVmIdToMovedAnimalLocList();
//
////	System.out.println("\nFrom inside the optimizeAllocation, the vms to migrate are: " + vmToMovedAnimalLocList+ "\n");
//		 // Code to find the location that matches the vm to the location
//		//A search for the vm in the vmIdToAnimalLocList
//		for(Map<String, Object> vmToMovedAnimalLoc: vmToMovedAnimalLocList ) {
//			for(Vm vm: vmList ) {
//			if( vm.getId()== (int)vmToMovedAnimalLoc.get("vm") ) {	//if the vm on the vmList matches an entry on vmIdToAnimalLocList
//				ZeroTrustLocation loc = (ZeroTrustLocation) vmToMovedAnimalLoc.get("animal");
//				//This code will calculate the host id from the animal location
//  				int hostRow = (int)	Math.floor(loc.getRow()/ 2);
//				int hostRowIdx = hostRow *100;
//				int hostColIdx = loc.getCol()/2;
//				hostNum = hostRowIdx + hostColIdx;
////	System.out.println("From optimizeAllocation, the calculated host number is " +hostNum);
//				for(PowerHost host : this.<PowerHost> getHostList()) {
//					if(host.getId()==hostNum) {
//						allocatedHost = host;
//					}//end if
//				}// end for
//			Map<String, Object> migrate = new HashMap<String, Object>();
//			migrate.put("vm", vm);
//			migrate.put("host", allocatedHost);
//			migrationMap.add(migrate);
////	System.out.println("In optimize map entries for vm " + vm.getId() + " to host " + allocatedHost.getId());
//			}//end if
//		}// end for
////	Log.printLine("VM #" + vm.getId() + " will be migrate from host #" + vm.getHost().getId()+ " to "+ allocatedHost.getId());
//		}//end for
//	System.out.println("\n");
//// System.out.println("The migration map from inside the optimizer is" + migrationMap);
//		return migrationMap;
//	}//end optimize
	
	/*
	 * (non-Javadoc)
	 * @see org.cloudbus.cloudsim.VmAllocationPolicy#deallocateHostForVm(org.cloudbus.cloudsim.Vm)
	 */
//	@Override
//	public void deallocateHostForVm(Vm vm) {
//		Host host = getVmTable().get(vm.getUid());
//		if (host != null) {// && !vm.isInMigration()
//			System.out.println("In deallocateHostForVm(Vm vm).  Deallocating " + vm.getId() + " for host " + getVmTable().get(vm.getUid()).getId());
//		}
//		getVmTable().remove(vm.getUid());
//			if (host != null) {// 
//				if(!(host.getVmScheduler().getVmsMigratingIn().contains(vm)&&host.getVmScheduler().getVmsMigratingOut().contains(vm))) {
//					System.out.println("The vmScheduler doesn't show the vm is migrating in and out at the same time in a single host");
//					System.out.println("The vm's migrating in are" + host.getVmScheduler().getVmsMigratingIn());
//					System.out.println("The vm's migrating out are" + host.getVmScheduler().getVmsMigratingOut());
//			host.vmDestroy(vm);
//				}else if((host.getVmScheduler().getVmsMigratingIn().contains(vm)&&host.getVmScheduler().getVmsMigratingOut().contains(vm))) {
//					host.getVmScheduler().getVmsMigratingOut().remove(vm);
//				}
//		}
//	}
	/*
	 * (non-Javadoc)
	 * @see org.cloudbus.cloudsim.VmAllocationPolicy#allocateHostForVm(org.cloudbus.cloudsim.Vm,
	 * org.cloudbus.cloudsim.Host)
	 */
	@Override
	public boolean allocateHostForVm(Vm vm, Host host) {
	if(host != null) {
	System.out.println("Attempting to allocateHostForVm, vm: " + vm.getId() + " host: " +host.getId());		
	}
		if (host == null) {
			Log.formatLine("%.2f: No suitable host found for VM #" + vm.getId() + "\n", CloudSim.clock());
			return false;
		}
		if (host.vmCreate(vm)) { // if vm has been succesfully created in the host
			getVmTable().put(vm.getUid(), host);
			Log.formatLine(
					"%.2f: VM #" + vm.getId() + " has been allocated to the host #" + host.getId(),
					CloudSim.clock());
			return true;
		}
		Log.formatLine(
				"%.2f: Creation of VM #" + vm.getId() + " on the host #" + host.getId() + " failed\n",
				CloudSim.clock());
		System.out.println("  A return false from the allocateHostForVm");
		return false;
	}
	/*
	 * (non-Javadoc)
	 * @see org.cloudbus.cloudsim.VmAllocationPolicy#deallocateHostForVm(org.cloudbus.cloudsim.Vm)
	 */
	@Override
	public void deallocateHostForVm(Vm vm) {
		Host host = getVmTable().get(vm.getUid());
//		System.out.println("[deallocateHostForVm] for vm: " + vm.getId() + " on host: " + host.getId() + " Press enter to continue");
//		try{System.in.read();}
//		catch(Exception e){}
		if (host != null) {// && !vm.isInMigration()
//			System.out.println("In deallocateHostForVm(Vm vm).  Deallocating " + vm.getId() + " for host " + getVmTable().get(vm.getUid()).getId());
		}
		getVmTable().remove(vm.getUid());
		if (host != null) {// && !vm.isInMigration()
			host.vmDestroy(vm);
		}
	}

	/**
	 * Gets the power after allocation.
	 * 
	 * @param host the host
	 * @param vm the vm
	 * 
	 * @return the power after allocation
	 */
	protected double getPowerAfterAllocation(PowerHost host, Vm vm) {
		double power = 0;
		try {
			System.out.println("This is a call for host: " + host.getId() + " getPowerModel().getPower(getMaxUtilizationAfterAllocation(host, vm) for vm: " +vm.getId());
			System.out.println("The getMaxUtilizationAfterAllocation(host, vm) is: " + getMaxUtilizationAfterAllocation(host, vm));
			System.out.println("The vms requested mips are: " + vm.getCurrentRequestedTotalMips());
			System.out.println("The Host vm list is: " + host.getVmList());
			System.out.println("And the vm's migrating in is: " + host.getVmsMigratingIn());
			for(Vm vm1: host.getVmList()) {
				System.out.println("vm: " + vm1.getId()+ " has requested mips " + vm1.getCurrentRequestedTotalMips());
			}
			power = host.getPowerModel().getPower(getMaxUtilizationAfterAllocation(host, vm));
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		return power;
	}

	/**
	 * Gets the power after allocation. We assume that load is balanced between PEs. The only
	 * restriction is: VM's max MIPS < PE's MIPS
	 * 
	 * @param host the host
	 * @param vm the vm
	 * 
	 * @return the power after allocation
	 */
	protected double getMaxUtilizationAfterAllocation(PowerHost host, Vm vm) {
		double requestedTotalMips = vm.getCurrentRequestedTotalMips();
		double hostUtilizationMips = getUtilizationOfCpuMips(host);
		double hostPotentialUtilizationMips = hostUtilizationMips + requestedTotalMips;
		double pePotentialUtilization = hostPotentialUtilizationMips / host.getTotalMips();
		return pePotentialUtilization;
	}
	
	/**
	 * Gets the utilization of the CPU in MIPS for the current potentially allocated VMs.
	 *
	 * @param host the host
	 *
	 * @return the utilization of the CPU in MIPS
	 */

	protected double getUtilizationOfCpuMips(PowerHost host) {
		double hostUtilizationMips = 0;
		for (Vm vm2 : host.getVmList()) {
			if (host.getVmsMigratingIn().contains(vm2)) {
				// calculate additional potential CPU usage of a migrating in VM
				hostUtilizationMips += host.getTotalAllocatedMipsForVm(vm2) * 0.9 / 0.1;
			}
			hostUtilizationMips += host.getTotalAllocatedMipsForVm(vm2);
		}
		return hostUtilizationMips;
	}
	
	/**
	 * Checks if is host over utilized after allocation.
	 * 
	 * @param host the host
	 * @param vm the vm
	 * @return true, if is host over utilized after allocation
	 */
	protected boolean isHostOverUtilizedAfterAllocation(PowerHost host, Vm vm) {
		boolean isHostOverUtilizedAfterAllocation = true;
		if (host.vmCreate(vm)) {
			isHostOverUtilizedAfterAllocation = isHostOverUtilized(host);
			host.vmDestroy(vm);
		}
		return isHostOverUtilizedAfterAllocation;
	}
	
	/**
	 * Adds the history value.
	 * 
	 * @param host the host
	 * @param metric the metric
	 */
	protected void addHistoryEntry(PowerHost host, double metric) {
		int hostId = host.getId();
		if (!getTimeHistory().containsKey(hostId)) {
			getTimeHistory().put(hostId, new LinkedList<Double>());
		}
		if (!getUtilizationHistory().containsKey(hostId)) {
			getUtilizationHistory().put(hostId, new LinkedList<Double>());
		}
		if (!getMetricHistory().containsKey(hostId)) {
			getMetricHistory().put(hostId, new LinkedList<Double>());
		}
		if (!getTimeHistory().get(hostId).contains(CloudSim.clock())) {
			getTimeHistory().get(hostId).add(CloudSim.clock());
			getUtilizationHistory().get(hostId).add(host.getUtilizationOfCpu());
			getMetricHistory().get(hostId).add(metric);
		}
	}

	@Override
	protected boolean isHostOverUtilized(PowerHost host) {
		// TODO Auto-generated method stub
		return false;
	}

}
