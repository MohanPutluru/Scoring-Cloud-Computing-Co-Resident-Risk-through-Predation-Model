/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package gametheory1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import predprey.Location;

import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmScheduler;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.lists.PeList;

import gametheory1.GameTheory1Runner;
/**
 * VmSchedulerFixedPe takes a location of host and vm and places the vm at a specific 
 * processing element
 */

public class GameTheory1VmScheduler extends VmScheduler {

	/** Map containing VM ID and a vector of PEs allocated to this VM. */
	private Map<String, List<Pe>> peAllocationMap;

	/** The free pes vector. */
	private List<Pe> freePes;

	/**
	 * Instantiates a new vm scheduler space shared.
	 * 
	 * @param pelist the pelist
	 */
	public GameTheory1VmScheduler(List<? extends Pe> pelist) {
		super(pelist);
		setPeAllocationMap(new HashMap<String, List<Pe>>());
		setFreePes(new ArrayList<Pe>());
		getFreePes().addAll(pelist);
	}

	/**
	 * Vm scheduler which reads the row and column of the vm location and places the vm on the correct number of the pe
	 */
	@Override
	public boolean allocatePesForVm(Vm vm, List<Double> mipsShare) {
	
		//if the vm is in migration but in an unknown status put the scheduler showing migrating out
		//if not in migratin and scheduler shows in migration out remove.
		if (vm.isInMigration()) {
			if (!getVmsMigratingIn().contains(vm.getUid()) && !getVmsMigratingOut().contains(vm.getUid())) {
				getVmsMigratingOut().add(vm.getUid());
			}//end if
		} else if(!(vm.isInMigration())) {
			if (getVmsMigratingOut().contains(vm.getUid())) {
				getVmsMigratingOut().remove(vm.getUid());
			}
		}//end else if
		
		List<Map<String, Object>> vmIdToAnimalLocList = GameTheory1Runner.getTranslator().getVmIdToNewAnimalLocList();  

//	If this is a new vm it uses the VmIdToNewAnimalLocList
		if(vm.getHost() == null && !GameTheory1Runner.getDatacenter().getVmList().contains(vm) && !vm.isInMigration()) {
//			 vmIdToAnimalLocList = GameTheoryRunner.getTranslator().getVmIdToNewAnimalLocList();  
			}
// This is test used in addMigratingInVm in [Host] or for migration to the same host		
		else if(vm.isInMigration() && !getVmsMigratingIn().contains(vm.getUid())) {
//	System.out.println("Used the vmIdToMovedAnimalLocList in early migration.");
			vmIdToAnimalLocList = GameTheory1Runner.getTranslator().getVmIdToMovedAnimalLocList();
		}
		else if(vm.isInMigration()&&(getVmsMigratingIn().contains(vm.getUid()) && !getVmsMigratingOut().contains(vm.getUid()))) {
			vmIdToAnimalLocList = GameTheory1Runner.getDatacenter().getVmToPeLocList();
//			System.out.println("Used the getVmToPeLocList in mid migration cycle.");
		}
		else if(vm.isInMigration()&&(!getVmsMigratingIn().contains(vm.getUid()) && getVmsMigratingOut().contains(vm.getUid()))) {
			vmIdToAnimalLocList = GameTheory1Runner.getDatacenter().getVmToPeLocList();
//			System.out.println("Used the getVmToPeLocList in mid migration cycle.");
		}
		else if(vm.isInMigration()&&(getVmsMigratingIn().contains(vm.getUid()) && getVmsMigratingOut().contains(vm.getUid()))) {
			vmIdToAnimalLocList = GameTheory1Runner.getTranslator().getVmIdToMovedAnimalLocList();
//			System.out.println("Used the getVmIdToMovedAnimalLocList in processVmCreate for same host.");
		}
		else if(!vm.isInMigration()) {
			vmIdToAnimalLocList = GameTheory1Runner.getDatacenter().getVmToPeLocList();
//			System.out.println("Used the getVmToPeLocList in late migration cycle.");
		}
	
		if (getFreePes().size() < mipsShare.size() && vmsMigratingOut == null) {
//			System.out.println("\n[VmSchedulaerFixedPe.allocatePesForVm] Failed in free pes.");
//			System.out.println("The mipsShare.size() was " + mipsShare.size() + ".  The free pes size was " + getFreePes().size());
			return false;
		}

	// selected pes is the list of pes assigned to the vm.  It can be one.
		List<Pe> selectedPes = new ArrayList<Pe>();
		Pe pe =null;
// Gets the host pelist
		List<Pe> peList = (List<Pe>) getPeList();
		double totalMips = 0;
	//A search for the vm in the vmIdToAnimalLocList
		for(Map<String, Object> vmIdToAnimalLoc: vmIdToAnimalLocList ) {
			Location loc = (Location) vmIdToAnimalLoc.get("animal");
			if((int) vmIdToAnimalLoc.get("vm")== vm.getId()) {
//	System.out.println("The selected host: "+  (int)(Math.floor(loc.getRow()/2)*100 + loc.getCol()/2) + " puts vm " + vm.getId()+ " on pe number " + (loc.getRow() % 2*2 + loc.getCol() % 2));
				int peNumber= (loc.getRow() % 2)*2 + (loc.getCol() % 2);
				pe = peList.get(peNumber);
				if(vm.getHost()!=null) {
				}
				} //end if
		}//End for
		for (Double mips : mipsShare) {
//	System.out.println("In mips check the mips are: " +mips);
			if (mips <= pe.getMips()) {
				selectedPes.add(pe);
			}
//	System.out.println("The vms migrating in in the schedular are: " + getVmsMigratingIn());
				totalMips += mips;
			}//End check for mips compatibility
		if (mipsShare.size() > selectedPes.size()) {
	System.out.println("If statement " + mipsShare.size() +" and "+ selectedPes.size());
			return false;
			}//Ends check to see if there are enough pes allocated

		getFreePes().removeAll(selectedPes);
		getPeAllocationMap().put(vm.getUid(), selectedPes);
		getMipsMap().put(vm.getUid(), mipsShare);
		setAvailableMips(getAvailableMips() - totalMips);
		return true;
	}

	/*
	 * set gametheory condition that
	 * if(getPeAllocationMap().get(vm.getUid())!=null)
	 * for host.vmDeallocate
	 */
	@Override
	public void deallocatePesForVm(Vm vm) {
//		System.out.println("[deallocatePesForVm] for " + vm.getId() + " Press enter to continue");
//		try{System.in.read();}
//		       catch(Exception e){}
		if(getPeAllocationMap().get(vm.getUid())!=null) {
		getFreePes().addAll(getPeAllocationMap().get(vm.getUid()));
		getPeAllocationMap().remove(vm.getUid());
		setAvailableMips(PeList.getTotalMips(getPeList()));
		double totalMips = 0;
		for (double mips : getMipsMap().get(vm.getUid())) {
		totalMips += mips;
		}
		setAvailableMips(getAvailableMips() + totalMips);
		getMipsMap().remove(vm.getUid());	
		}
	}

	/**
	 * Sets the pe allocation map.
	 * 
	 * @param peAllocationMap the pe allocation map
	 */
	protected void setPeAllocationMap(Map<String, List<Pe>> peAllocationMap) {
		this.peAllocationMap = peAllocationMap;
	}

	/**
	 * Gets the pe allocation map.
	 * 
	 * @return the pe allocation map
	 */
	protected Map<String, List<Pe>> getPeAllocationMap() {
		return peAllocationMap;
	}
@Override
	/**
	 * Gets the pe map.
	 * 
	 * @return the pe map
	 */
	public Map<String, List<Pe>> getPeMap() {
		return peAllocationMap;
	}
	
	/**
	 * Sets the free pes vector.
	 * 
	 * @param freePes the new free pes vector
	 */
	protected void setFreePes(List<Pe> freePes) {
		this.freePes = freePes;
	}

	/**
	 * Gets the free pes vector.
	 * 
	 * @return the free pes vector
	 */
	protected List<Pe> getFreePes() {
		return freePes;
	}

}
