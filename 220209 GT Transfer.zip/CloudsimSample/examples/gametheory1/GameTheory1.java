package gametheory1;

import java.io.IOException;



/**
 * A predation model of game theory applied to the cloud.
 * Takes in a workload and applies it to virtual machines that represent a predator and 
 * prey in a landscape.  At intervals the two species act and the results are applied to the 
 * cloud simulation for there outputs.
 */
public class GameTheory1 {

	/**
	 * The main method.      
	 * 
	 * @param args the arguments
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void main(String[] args) throws IOException {
		boolean enableOutput = true;
		boolean outputToFile = false;
//		String inputFolder = IqrMu.class.getClassLoader().getResource("workload/planetlab").getPath();
//		String inputFolder = "Workload";
		String inputFolder = "examples";
		String outputFolder = "output";
//		String workload = "20110302"; // PlanetLab workload
		String workload = "1_ZeroTrust2Data"; // PlanetLab workload
		String vmAllocationPolicy = "gameTheory1"; 
		String vmSelectionPolicy = "mu"; 
		String parameter = "1.5"; // the safety parameter of the IQR policy

		new GameTheory1Runner(
				enableOutput,
				outputToFile,
				inputFolder,
				outputFolder,
				workload,
				vmAllocationPolicy,
				vmSelectionPolicy,
				parameter);
	}

}
