package gametheory1;
import java.util.Scanner;
public class PandP {

	public static void main(String[] args) {
		GameTheory1Simulator PredPrey = new GameTheory1Simulator();
//		PredPrey.populate();
//		PredPrey.simulateOneStep();
//		PredPrey.simulate(500);
//// Experimental stepping routine	
////		public void promptEnterKey(){
		int step = 0;
		while(true) {
		System.out.println("Step " + step + " Press \"ENTER\" to continue...");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		scanner.nextLine();	
		PredPrey.simulateOneStep();
		step++;
		}
		

//		System.out.println("2. Press \"ENTER\" to continue...");
//		scanner.nextLine();
//		PredPrey.simulateOneStep();
//		System.out.println("3. Press \"ENTER\" to continue...");
//		scanner.nextLine();
//		PredPrey.simulateOneStep();
//		System.out.println("4. Press \"ENTER\" to continue...");
//		scanner.nextLine();
//		PredPrey.simulateOneStep();
	}

}
