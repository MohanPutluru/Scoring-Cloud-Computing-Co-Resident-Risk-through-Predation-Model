package gametheory1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudSim;

import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationAbstract;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationInterQuartileRange;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationLocalRegression;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationLocalRegressionRobust;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationMedianAbsoluteDeviation;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicyMigrationStaticThreshold;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicySimple;
import org.cloudbus.cloudsim.power.PowerVmSelectionPolicy;
import org.cloudbus.cloudsim.power.PowerVmSelectionPolicyMaximumCorrelation;
import org.cloudbus.cloudsim.power.PowerVmSelectionPolicyMinimumMigrationTime;
import org.cloudbus.cloudsim.power.PowerVmSelectionPolicyMinimumUtilization;
import org.cloudbus.cloudsim.power.PowerVmSelectionPolicyRandomSelection;

import gametheory1.GameTheory1Datacenter;
import gametheory1.GameTheory1DatacenterBroker;
import gametheory1.GameTheory1PowerVmAllocationPolicyMigration;
import gametheory1.GameTheory1Simulator;

/**
 * The runner for the game theory model
 */



public class GameTheory1Runner  {

// A predation model to provide the allocation data	
// translator provides data to CloudSim classes.
private static GameTheory1Simulator translator;
// provides a datacenter to provide access to variables in that class
private static GameTheory1Datacenter dcAccess;
// local host list for type of hostlist
private static List<PowerHost> hostList;
// local input folder for access to cloudlet list
public static String inputFolder;
/** The enable output. */
private static boolean enableOutput;

/** The broker. */
protected static GameTheory1DatacenterBroker broker;

/** The cloudlet list. */
protected static List<Cloudlet> cloudletList;

/** The vm list. */
protected static List<Vm> vmList;

	/**
	 * Instantiates a new predation runner.
	 * 
	 * @param enableOutput the enable output
	 * @param outputToFile the output to file
	 * @param inputFolder the input folder
	 * @param outputFolder the output folder
	 * @param workload the workload
	 * @param vmAllocationPolicy the vm allocation policy
	 * @param vmSelectionPolicy the vm selection policy
	 * @param parameter the parameter
	 */
	public GameTheory1Runner(
			boolean enableOutput,
			boolean outputToFile,
			String inputFolder,
			String outputFolder,
			String workload,
			String vmAllocationPolicy,
			String vmSelectionPolicy,
			String parameter) {
		try {
			initLogOutput(
					enableOutput,
					outputToFile,
					outputFolder,
					workload,
					vmAllocationPolicy,
					vmSelectionPolicy,
					parameter);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		init(inputFolder + "/" + workload);
		start(
				getExperimentName(workload, vmAllocationPolicy, vmSelectionPolicy, parameter),
				outputFolder,
				getVmAllocationPolicy(vmAllocationPolicy, vmSelectionPolicy, parameter));
		
	}
	
	/**
	 * Inits the log output.
	 * 
	 * @param enableOutput the enable output
	 * @param outputToFile the output to file
	 * @param outputFolder the output folder
	 * @param workload the workload
	 * @param vmAllocationPolicy the vm allocation policy
	 * @param vmSelectionPolicy the vm selection policy
	 * @param parameter the parameter
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws FileNotFoundException the file not found exception
	 */
	protected void initLogOutput(
			boolean enableOutput,
			boolean outputToFile,
			String outputFolder,
			String workload,
			String vmAllocationPolicy,
			String vmSelectionPolicy,
			String parameter) throws IOException, FileNotFoundException {
		setEnableOutput(enableOutput);
		Log.setDisabled(!isEnableOutput());
		if (isEnableOutput() && outputToFile) {
			File folder = new File(outputFolder);
			if (!folder.exists()) {
				folder.mkdir();
			}

			File folder2 = new File(outputFolder + "/log");
			if (!folder2.exists()) {
				folder2.mkdir();
			}

			File file = new File(outputFolder + "/log/"
					+ getExperimentName(workload, vmAllocationPolicy, vmSelectionPolicy, parameter) + ".txt");
			file.createNewFile();
			Log.setOutput(new FileOutputStream(file));
		}
	}
	/**
	 * Gets the experiment name.
	 * 
	 * @param args the args
	 * @return the experiment name
	 */
	protected String getExperimentName(String... args) {
		StringBuilder experimentName = new StringBuilder();
		for (int i = 0; i < args.length; i++) {
			if (args[i].isEmpty()) {
				continue;
			}
			if (i != 0) {
				experimentName.append("_");
			}
			experimentName.append(args[i]);
		}
		return experimentName.toString();
	}

	/**
	 * Sets the enable output.
	 * 
	 * @param enableOutput the new enable output
	 */
	public void setEnableOutput(boolean enableOutput) {
		enableOutput = enableOutput;
	}

	/**
	 * Checks if is enable output.
	 * 
	 * @return true, if is enable output
	 */
	public boolean isEnableOutput() {
		return enableOutput;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.cloudbus.cloudsim.examples.power.RunnerAbstract#init(java.lang.String)
	 */

	protected void init(String inputFolder) {
		try {
			CloudSim.init(1, Calendar.getInstance(), false);
			
// Sets the landscape as the mirror to the game theory model to the datacenter
		 	GameTheory1Simulator landscape = GameTheory1Helper.createLandscape();
// The Translator provides game theory information to CloudSim
		 	setTranslator(landscape);
// Provides vm id to the location of the animal in the landscape		 	
		 	List<Map<String, Object>> vmIdToAnimalLocList = landscape.getVmIdToAnimalLocList();
// Creates a GameTheoryDatacenterBroker	 	
			broker = GameTheory1Helper.createBroker();
			int brokerId = broker.getId();
// sets broker to have access for the cloudlest submission			
			setBroker(broker);
//	makes the input folder avaibable to obtain cloudlets on game turn
			setInputFolder(inputFolder);
// Creates a cloudlet list, 
			cloudletList = GameTheory1Helper.createCloudletListPlanetLab(brokerId, inputFolder, vmIdToAnimalLocList);
// vm list with ids the hash of the animal
			vmList = GameTheory1Helper.createVmList(brokerId, vmIdToAnimalLocList);
// GameTheory1PowerHost list with datacenter dimensions supplied by the PlanetLabConstants			
			hostList = (List<PowerHost>) GameTheory1Helper.createHostList(GameTheory1Constants.HOST_HEIGHT, GameTheory1Constants.HOST_WIDTH);
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
			System.exit(0);
		}
	}
	//Setter and Getter for the translator	
		public static void setTranslator(GameTheory1Simulator landscape) {
			translator = landscape;
		}
		public static GameTheory1Simulator getTranslator() {
			return translator;
		}
			/**
		 * @param broker the broker to set
		 */
		public static void setBroker(GameTheory1DatacenterBroker broker) {
			broker = broker;
		}
		/**
		 * @return the broker
		 */
		public static GameTheory1DatacenterBroker getBroker() {
			return broker;
		}
		/**
		 * @param cloudletList the cloudletList to set
		 */
		public static void setCloudletList(List<Cloudlet> cloudletList) {
			cloudletList = cloudletList;
		}	
		/* @return the cloudletList
		 */
		public static List<Cloudlet> getCloudletList() {
			return cloudletList;
		}

		/**
		 * @param inputFolder the inputFolder to set
		 */
		public static void setInputFolder(String inputFolder) {
			GameTheory1Runner.inputFolder = inputFolder;
		}
		/**
		 * @return the inputFolder
		 */
		public static String getInputFolder() {
			return inputFolder;
		}


	/**
	 * Starts the simulation.
	 * 
	 * @param experimentName the experiment name
	 * @param outputFolder the output folder
	 * @param vmAllocationPolicy the vm allocation policy
	 */
	protected void start(String experimentName, String outputFolder, VmAllocationPolicy vmAllocationPolicy) {
		System.out.println("Starting " + experimentName);
		/** Creates a matrix to store data in
		*The output will be placed in rows with data in columns.  Each row will have a time stamp
		and numbers of vms/animals by type and total.  For each hosts power consumption for a time period.
		The output will be arranged in .csv format.
		*/
		try {
		File opfile = new File("C:\\Users\\HP_PC\\Documents\\GameTheory.csv"); 
		//automatically the file is created in the project folder
		//File opfile = new File("Output1.csv");
		if (opfile.createNewFile()) {
		Log.printLine("File created: " + opfile.getName() + "\n");
		} 
		else {
		Log.printLine("Deleting/overwritting opfile...\n");
		opfile.delete();
		}
		} catch (IOException e) {
		System.out.println("An error occurred.");
		}

		try {
//Altered to GameTheoryDatacenter			
			GameTheory1Datacenter datacenter = (GameTheory1Datacenter) GameTheory1Helper.createDatacenter(
					"Datacenter",
					GameTheory1Datacenter.class,
					hostList,
					vmAllocationPolicy);

			datacenter.setDisableMigrations(false);
			setDatacenter(datacenter);
			broker.submitVmList(vmList);	
			broker.submitCloudletList(cloudletList);

			CloudSim.terminateSimulation(GameTheory1Constants.SIMULATION_LIMIT);
			double lastClock = CloudSim.startSimulation();

			List<Cloudlet> newList = broker.getCloudletReceivedList();
			Log.printLine("Received " + newList.size() + " cloudlets");

			CloudSim.stopSimulation();

			GameTheory1Helper.printResults(
					datacenter,
					vmList,
					lastClock,
					experimentName,
					GameTheory1Constants.OUTPUT_CSV,
					outputFolder);

		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
			System.exit(0);
		}

		Log.printLine("Finished " + experimentName);
	}
	 public static GameTheory1Datacenter getDatacenter() {
			return dcAccess;
		}
	/**
	 * @param datacenter the datacenter to set
	 */
	public static void setDatacenter(GameTheory1Datacenter datacenter) {
		dcAccess = datacenter;
	}
	
	/**
	 * Gets the vm allocation policy.
	 * 
	 * @param vmAllocationPolicyName the vm allocation policy name
	 * @param vmSelectionPolicyName the vm selection policy name
	 * @param parameterName the parameter name
	 * @return the vm allocation policy
	 */
	
	protected VmAllocationPolicy getVmAllocationPolicy(
			String vmAllocationPolicyName,
			String vmSelectionPolicyName,
			String parameterName) {
		VmAllocationPolicy vmAllocationPolicy = null;
		PowerVmSelectionPolicy vmSelectionPolicy = null;
		if (!vmSelectionPolicyName.isEmpty()) {
			vmSelectionPolicy = getVmSelectionPolicy(vmSelectionPolicyName);
		}
		double parameter = 0;
		if (!parameterName.isEmpty()) {
			parameter = Double.valueOf(parameterName);
		}
		if (vmAllocationPolicyName.equals("iqr")) {
//			System.out.println("The vm allocation policy being used is IQR");
//		CloudSim.pauseSimulation(2);
			PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					0.7);
			vmAllocationPolicy = new PowerVmAllocationPolicyMigrationInterQuartileRange(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("mad")) {
			PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					0.7);
			vmAllocationPolicy = new PowerVmAllocationPolicyMigrationMedianAbsoluteDeviation(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lr")) {
			PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					0.7);
			vmAllocationPolicy = new PowerVmAllocationPolicyMigrationLocalRegression(
					hostList,
					vmSelectionPolicy,
					parameter,
					GameTheory1Constants.SCHEDULING_INTERVAL,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("lrr")) {
			PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					0.7);
			vmAllocationPolicy = new PowerVmAllocationPolicyMigrationLocalRegressionRobust(
					hostList,
					vmSelectionPolicy,
					parameter,
					GameTheory1Constants.SCHEDULING_INTERVAL,
					fallbackVmSelectionPolicy);
		} else if (vmAllocationPolicyName.equals("thr")) {
			vmAllocationPolicy = new PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					parameter);
		} else if (vmAllocationPolicyName.equals("dvfs")) {
			vmAllocationPolicy = new PowerVmAllocationPolicySimple(hostList);
		} else if (vmAllocationPolicyName.equals("gameTheory1")) {
			PowerVmAllocationPolicyMigrationAbstract fallbackVmSelectionPolicy = new PowerVmAllocationPolicyMigrationStaticThreshold(
					hostList,
					vmSelectionPolicy,
					0.7);
			vmAllocationPolicy = new GameTheory1PowerVmAllocationPolicyMigration(
					hostList,
					vmSelectionPolicy,
					parameter,
					fallbackVmSelectionPolicy);
		}else {
			System.out.println("Unknown VM allocation policy: " + vmAllocationPolicyName);
			System.exit(0);
		}
		return vmAllocationPolicy;
	}
	
	/**
	 * Gets the vm selection policy.
	 * 
	 * @param vmSelectionPolicyName the vm selection policy name
	 * @return the vm selection policy
	 */
	protected PowerVmSelectionPolicy getVmSelectionPolicy(String vmSelectionPolicyName) {
		PowerVmSelectionPolicy vmSelectionPolicy = null;
		if (vmSelectionPolicyName.equals("mc")) {
			vmSelectionPolicy = new PowerVmSelectionPolicyMaximumCorrelation(
					new PowerVmSelectionPolicyMinimumMigrationTime());
		} else if (vmSelectionPolicyName.equals("mmt")) {
			vmSelectionPolicy = new PowerVmSelectionPolicyMinimumMigrationTime();
		} else if (vmSelectionPolicyName.equals("mu")) {
			vmSelectionPolicy = new PowerVmSelectionPolicyMinimumUtilization();
		} else if (vmSelectionPolicyName.equals("rs")) {
			vmSelectionPolicy = new PowerVmSelectionPolicyRandomSelection();
		} else {
			System.out.println("Unknown VM selection policy: " + vmSelectionPolicyName);
			System.exit(0);
		}
		return vmSelectionPolicy;
	}
}


