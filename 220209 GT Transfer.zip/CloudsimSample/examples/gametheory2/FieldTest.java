package gametheory2;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * A main method to execute the predator-prey domain without the CloudSim interface.
 * 
 * This code takes from the GameTheorySimulator values and the referenced classes.
 * It is able to be run to the population (zero) step, one step, or any number of steps.
 * A looping code executes steps awaiting user input by "Enter".
 */
public class FieldTest {

	public static void main(String[] args) {
		GameTheorySimulator PredPrey = new GameTheorySimulator();
		
//		PredPrey.populate();
		
//		PredPrey.simulateOneStep();
		
//		PredPrey.simulate(500);
		
/**
* Stepping Routine
* Output file readable by Matlab code.
* 
*/

int step = 0;
	while(true) {
		System.out.println("Step " + step + " Press \"ENTER\" to continue...");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		scanner.nextLine();	
		PredPrey.simulateOneStep();
		step++;
		final double[] DataMatrix = new double[6];
		DataMatrix[0]=step;
		DataMatrix[1]=PredPrey.getVmIdToAnimalLocList().size();
		DataMatrix[2]=PredPrey.getRabbits().size();
		DataMatrix[3]=PredPrey.getFoxes().size();
		DataMatrix[4]=PredPrey.getHuntedRabbits();
		DataMatrix[5]=PredPrey.getVmIdToDeadAnimalLocList().size();
		WriteResultsToFile(DataMatrix);
		}
	}
	// The method to write results to external file
	private static void WriteResultsToFile(double[] results){
		//create a file writer
		FileWriter fw;
		try {
	/** Constructs a FileWriter object given a File object.
	Pass true as second parameter to the constructor of FileWriter to instruct the writer to append the data 
	instead of rewriting the file. */
			fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\FieldTest.csv", true); 
			try (PrintWriter pw = new PrintWriter(fw)) {
	//Writes the number of columns, the range of the DataMatrix
	for(int i = 0; i < results.length; i++){
	pw.print(results[i]);
	//to separate the values by comma, when opened in .txt format.
	pw.print(",");
	}
	pw.println();
	//Flush the output to the file
	pw.flush();
	//Close the Print Writer
	pw.close();
	}
	//Close the File Writer
	fw.close();
//Marker for writing to output file.
//	System.out.println("Successfully wrote to the file.");
	} catch (IOException e) {
	}
	}
}
