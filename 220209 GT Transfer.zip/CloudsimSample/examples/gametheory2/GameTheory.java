package gametheory2;

import java.io.IOException;



/**
 * A predation model of game theory applied to the cloud.
 * Takes in a workload and applies it to virtual machines that represent a predator and 
 * prey in a landscape.  At intervals the two species act and the results are applied to the 
 * cloud simulation for there outputs.
 */
public class GameTheory {

	/**
	 * The main method.
	 * 
	 * @param args the arguments
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void main(String[] args) throws IOException {
		boolean enableOutput = true;
		boolean outputToFile = false;
//		String inputFolder = IqrMu.class.getClassLoader().getResource("workload/planetlab").getPath();
//		String inputFolder = "Workload";
		String inputFolder = "examples";
		String outputFolder = "output";
//		String workload = "20110302"; // PlanetLab workload
		String workload = "2_GameTheory1Data"; // PlanetLab workload
		String vmAllocationPolicy = "gameTheory"; // Inter Quartile Range (IQR) VM allocation policy
		String vmSelectionPolicy = "GT"; // Minimum Utilization (MU) VM selection policy
		String parameter = "1.5"; // the safety parameter of the IQR policy

		new GameTheoryRunner(
				enableOutput,
				outputToFile,
				inputFolder,
				outputFolder,
				workload,
				vmAllocationPolicy,
				vmSelectionPolicy,
				parameter);
	}

}
