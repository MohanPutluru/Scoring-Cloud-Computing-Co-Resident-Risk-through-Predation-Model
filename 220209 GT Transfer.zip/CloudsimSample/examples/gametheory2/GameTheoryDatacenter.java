/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package gametheory2;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudInformationService;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.FutureQueue;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;
import org.cloudbus.cloudsim.core.predicates.PredicateNotType;
import org.cloudbus.cloudsim.power.PowerHost;


/**
 * GameTheoryDatacenter is a class that enables simulation of power-aware data centers.
 * 
 */
public class GameTheoryDatacenter extends Datacenter {

	/** The datacenter consumed power. */
	private double power;

	/** Indicates if migrations are disabled or not. */
	private boolean disableMigrations;

	/** The last time submitted cloudlets were processed. */
	private double cloudletSubmitted;

	/** The VM migration count. */
	private int migrationCount;
	
	/** The time period count. */
	public int timePeriodCount;
	
	/** The VM to PE placement List. */
	public List<Map<String,Object>> vmIdToPeLocList = new ArrayList<Map<String, Object>>();

	/** The a cloudlet ID to increments paused. */
	public ArrayList<Map<String, Object>> pauseCloudletList = new ArrayList<Map<String,Object>>();
	/**
	/**
	 * Instantiates a new PowerDatacenter.
	 * 
	 * @param name the datacenter name
	 * @param characteristics the datacenter characteristics
	 * @param schedulingInterval the scheduling interval
	 * @param vmAllocationPolicy the vm provisioner
	 * @param storageList the storage list
	 * @throws Exception the exception
	 */
	public GameTheoryDatacenter(
			String name,
			DatacenterCharacteristics characteristics,
			VmAllocationPolicy vmAllocationPolicy,
			List<Storage> storageList,
			double schedulingInterval) throws Exception {
		super(name, characteristics, vmAllocationPolicy, storageList, schedulingInterval);

		setPower(0.0);
		setDisableMigrations(false);
		setCloudletSubmitted(-1);
		setMigrationCount(0);
		setTimePeriodCount(0);
	}

	/**
	 * Processes events or services that are available for this PowerDatacenter.
	 * 
	 * @param ev a Sim_event object
	 * @pre ev != null
	 * @post $none
	 */
	@Override
	public void processEvent(SimEvent ev) {
		int srcId = -1;

		switch (ev.getTag()) {
		// Resource characteristics inquiry
			case CloudSimTags.RESOURCE_CHARACTERISTICS:
				srcId = ((Integer) ev.getData()).intValue();
				sendNow(srcId, ev.getTag(), getCharacteristics());
				break;

			// Resource dynamic info inquiry
			case CloudSimTags.RESOURCE_DYNAMICS:
				srcId = ((Integer) ev.getData()).intValue();
				sendNow(srcId, ev.getTag(), 0);
				break;

			case CloudSimTags.RESOURCE_NUM_PE:
				srcId = ((Integer) ev.getData()).intValue();
				int numPE = getCharacteristics().getNumberOfPes();
				sendNow(srcId, ev.getTag(), numPE);
				break;

			case CloudSimTags.RESOURCE_NUM_FREE_PE:
				srcId = ((Integer) ev.getData()).intValue();
				int freePesNumber = getCharacteristics().getNumberOfFreePes();
				sendNow(srcId, ev.getTag(), freePesNumber);
				break;

			// New Cloudlet arrives
			case CloudSimTags.CLOUDLET_SUBMIT:
				processCloudletSubmit(ev, false);
				break;

			// New Cloudlet arrives, but the sender asks for an ack
			case CloudSimTags.CLOUDLET_SUBMIT_ACK:
				processCloudletSubmit(ev, true);
				break;

			// Cancels a previously submitted Cloudlet
			case CloudSimTags.CLOUDLET_CANCEL:
				processCloudlet(ev, CloudSimTags.CLOUDLET_CANCEL);
				break;

			// Pauses a previously submitted Cloudlet
			case CloudSimTags.CLOUDLET_PAUSE:
				processCloudlet(ev, CloudSimTags.CLOUDLET_PAUSE);
				break;

			// Pauses a previously submitted Cloudlet, but the sender
			// asks for an acknowledgement
			case CloudSimTags.CLOUDLET_PAUSE_ACK:
				processCloudlet(ev, CloudSimTags.CLOUDLET_PAUSE_ACK);
				break;

			// Resumes a previously submitted Cloudlet
			case CloudSimTags.CLOUDLET_RESUME:
				processCloudlet(ev, CloudSimTags.CLOUDLET_RESUME);
				break;

			// Resumes a previously submitted Cloudlet, but the sender
			// asks for an acknowledgement
			case CloudSimTags.CLOUDLET_RESUME_ACK:
				processCloudlet(ev, CloudSimTags.CLOUDLET_RESUME_ACK);
				break;

			// Moves a previously submitted Cloudlet to a different resource
			case CloudSimTags.CLOUDLET_MOVE:
				processCloudletMove((int[]) ev.getData(), CloudSimTags.CLOUDLET_MOVE);
				break;

			// Moves a previously submitted Cloudlet to a different resource
			case CloudSimTags.CLOUDLET_MOVE_ACK:
				processCloudletMove((int[]) ev.getData(), CloudSimTags.CLOUDLET_MOVE_ACK);
				break;

			// Checks the status of a Cloudlet
			case CloudSimTags.CLOUDLET_STATUS:
				processCloudletStatus(ev);
				break;

			// Ping packet
			case CloudSimTags.INFOPKT_SUBMIT:
				processPingRequest(ev);
				break;

			case CloudSimTags.VM_CREATE:
				SimEvent event1 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_MIGRATE));
				SimEvent event2 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_MIGRATE_ACK));
				if (!(event1 == null && event2 == null)) {
					System.out.println("the deffered queue has migrate and " + CloudSim.findFirstDeferred(srcId, new PredicateNotType(CloudSimTags.VM_MIGRATE)) +" Press enter to continue");
					try{System.in.read();}
					        catch(Exception e){}
					send(getId(), CloudSim.getMinTimeBetweenEvents()*5, CloudSimTags.VM_CREATE, (Object) ev.getData());
				}else
				processVmCreate(ev, false);
				break;

			case CloudSimTags.VM_CREATE_ACK:
				processVmCreate(ev, true);
				break;

			case CloudSimTags.VM_DESTROY:
				processVmDestroy(ev, false);
				break;

			case CloudSimTags.VM_DESTROY_ACK:
				processVmDestroy(ev, true);
				break;

			case CloudSimTags.VM_MIGRATE:
				processVmMigrate(ev, false);
				break;

			case CloudSimTags.VM_MIGRATE_ACK:
				SimEvent event3 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_DESTROY));
				SimEvent event4 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_DESTROY_ACK));
				if (!(event3 == null || event4 == null)) {
					send(getId(), CloudSim.getMinTimeBetweenEvents()*5, CloudSimTags.VM_MIGRATE, (Object) ev.getData());
				}else
				processVmMigrate(ev, true);
				break;

			case CloudSimTags.VM_DATA_ADD:
				processDataAdd(ev, false);
				break;

			case CloudSimTags.VM_DATA_ADD_ACK:
				processDataAdd(ev, true);
				break;

			case CloudSimTags.VM_DATA_DEL:
				processDataDelete(ev, false);
				break;

			case CloudSimTags.VM_DATA_DEL_ACK:
				processDataDelete(ev, true);
				break;

			case CloudSimTags.VM_DATACENTER_EVENT:
				incrementTimePeriodCount();
				System.out.println("The time period count is: " + getTimePeriodCount()+ "\n");
				System.out.println("D/C #" + getId() + ": VM_DATACENTER_EVENT at " + CloudSim.clock());
//				System.out.println("The number of cloudlets running is: " + cloudletPausedList.size());
//				System.out.println("[GameTheoryDatacenter, CloudSimTags.VM_DATACENTER_EVENT Press enter to continue");
//				try{System.in.read();}
//				catch(Exception e){}
				updateCloudletProcessing();
				checkCloudletCompletion();
				break;
				
			// other unknown tags are processed by this method
			default:
				processOtherEvent(ev);
				break;
		}
	}
	@Override
	protected void updateCloudletProcessing() {
		if (getCloudletSubmitted() == -1 || getCloudletSubmitted() == CloudSim.clock()) {
			CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.VM_DATACENTER_EVENT)); // a predicate type based on cloudlet predicate
			schedule(getId(), getSchedulingInterval(), CloudSimTags.VM_DATACENTER_EVENT);
			return;
		}
		double currentTime = CloudSim.clock();

		// if some time passed since last processing
		if (currentTime > getLastProcessTime()) {
			// This is a test to determine if it is possible to index the power outputCloudSimTags.VM_DATACENTER_EVENT

			double minTime = updateCloudetProcessingWithoutSchedulingFutureEventsForce();
//	Code to initiate and execute migrations		
			List<Vm> newVmList= GameTheoryHelper.createVmList(CloudSim.getEntityId("Broker"), GameTheoryRunner.getTranslator().simulateOneStep());
			queueHackedCloudlets();
			GameTheoryRunner.getBroker().submitNewVmList(newVmList);
//			try {
//				List<Cloudlet> cloudletList = GameTheoryHelper.createCloudletListPlanetLab(GameTheoryRunner.getBroker().getId(), GameTheoryRunner.getInputFolder(), GameTheoryRunner.getTranslator().getVmIdToNewAnimalLocList());
//				GameTheoryRunner.getBroker().submitNewCloudletList(cloudletList);
//			} catch (FileNotFoundException e) {
//				e.printStackTrace();
//			}
			GameTheoryRunner.getBroker().newVmsCreate();
			if(GameTheoryRunner.getBroker().getCloudletReceivedList().size() < 0) {
				GameTheoryRunner.getBroker().newVmsCloudletsSubmit();
			}

			if (!isDisableMigrations()) {
				List<Map<String, Object>> migrationMap = getVmAllocationPolicy().optimizeAllocation(getVmList());
        				                    
				if (migrationMap != null) {
					for (Map<String, Object> migrate : migrationMap) {
						Vm vm = (Vm) migrate.get("vm");
						PowerHost targetHost = (PowerHost) migrate.get("host");
						PowerHost oldHost = (PowerHost) vm.getHost();

						if (oldHost == null) {
							Log.formatLine(
									"\n%.2f: Migration of VM #%d to Host #%d is started",
									currentTime,
									vm.getId(),
									targetHost.getId());
						} else {
							Log.formatLine(
									"\n%.2f: Migration of VM #%d from Host #%d to Host #%d is started",
									currentTime,
									vm.getId(),
									oldHost.getId(),
									targetHost.getId());
						}

						targetHost.addMigratingInVm(vm);
						incrementMigrationCount();

						/** VM migration delay = RAM / bandwidth **/
						// we use BW / 2 to model BW available for migration purposes, the other
						// half of BW is for VM communication
						// around 16 seconds for 1024 MB using 1 Gbit/s network
						
						send(
								getId(),
								vm.getRam() / ((double) targetHost.getBw() / (2 * 8000)),
								CloudSimTags.VM_MIGRATE,
								migrate);
					}
				}
			}

			// schedules an event to the next time
			if (minTime != Double.MAX_VALUE) {
				CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.VM_DATACENTER_EVENT));
// Marker for the schedule of the next event at the scheduling interval
				System.out.println("The next scheduling of vm_dc_evt is at " + (currentTime+getSchedulingInterval()));
				send(getId(), getSchedulingInterval(), CloudSimTags.VM_DATACENTER_EVENT);
			}

			setLastProcessTime(currentTime);
		}
	}

	/**
	 * Update cloudet processing without scheduling future events.
	 * 
	 * @return the double
         * @see #updateCloudetProcessingWithoutSchedulingFutureEventsForce() 
         * @todo There is an inconsistence in the return value of this
         * method with return value of similar methods
         * such as {@link #updateCloudetProcessingWithoutSchedulingFutureEventsForce()},
         * that returns {@link Double#MAX_VALUE} by default.
         * The current method returns 0 by default.
	 */
	protected double updateCloudetProcessingWithoutSchedulingFutureEvents() {
		if (CloudSim.clock() > getLastProcessTime()) {
			return updateCloudetProcessingWithoutSchedulingFutureEventsForce();
		}
		return 0;
	}

	/**
	 * Update cloudet processing without scheduling future events.
	 * 
	 * @return expected time of completion of the next cloudlet in all VMs of all hosts or
	 *         {@link Double#MAX_VALUE} if there is no future events expected in this host
	 */
	protected double updateCloudetProcessingWithoutSchedulingFutureEventsForce() {
		double currentTime = CloudSim.clock();
		double minTime = Double.MAX_VALUE;
		double timeDiff = currentTime - getLastProcessTime();
		double timeFrameDatacenterEnergy = 0.0;
		//Output to be read for Game Theory Data in Matlab
		final double[] DataMatrix = new double[6+GameTheoryConstants.HOST_WIDTH*GameTheoryConstants.HOST_HEIGHT];
		DataMatrix[0]=currentTime;
		DataMatrix[1]=getVmList().size();
		DataMatrix[2]=GameTheoryRunner.getTranslator().getRabbits().size();
		DataMatrix[3]=GameTheoryRunner.getTranslator().getFoxes().size();
		DataMatrix[4]=getMigrationCount();
		DataMatrix[5] = GameTheoryRunner.getTranslator().getHuntedRabbits();

				Log.printLine("\n\n--------------------------------------------------------------\n\n");
				Log.formatLine("New resource usage for the time frame starting at %.2f:", currentTime);

				for (PowerHost host : this.<PowerHost> getHostList()) {
//					Log.printLine("\nFor host" + host.getId()+ " update vms processing.");
//					System.out.println("");
					double time = host.updateVmsProcessing(currentTime); // inform VMs to update processing
					if (time < minTime) {
						minTime = time;
					}

					Log.formatLine(
							"%.2f: [Host #%d] utilization is %.2f%%",
							currentTime,
							host.getId(),
							host.getUtilizationOfCpu() * 100);
				}

				if (timeDiff > 0) {
					Log.formatLine(
							"\nEnergy consumption for the last time frame from %.2f to %.2f:",
							getLastProcessTime(),
							currentTime);

					for (PowerHost host : this.<PowerHost> getHostList()) {
						double previousUtilizationOfCpu = host.getPreviousUtilizationOfCpu();
						double utilizationOfCpu = host.getUtilizationOfCpu();
						double timeFrameHostEnergy = host.getEnergyLinearInterpolation(
								previousUtilizationOfCpu,
								utilizationOfCpu,
								timeDiff);
						timeFrameDatacenterEnergy += timeFrameHostEnergy;

						Log.printLine();
						Log.formatLine(
								"%.2f: [Host #%d] utilization at %.2f was %.2f%%, now is %.2f%%",
								currentTime,
								host.getId(),
								getLastProcessTime(),
								previousUtilizationOfCpu * 100,
								utilizationOfCpu * 100);
						Log.formatLine(
								"%.2f: [Host #%d] energy is %.2f W*sec",
								currentTime,
								host.getId(),
								timeFrameHostEnergy);
						//Output of Host power
						DataMatrix[getHostList().indexOf(host)+6]=timeFrameHostEnergy;
					}
			Log.formatLine(
					"\n%.2f: Data center's energy is %.2f W*sec\n",
					currentTime,
					timeFrameDatacenterEnergy);
		}

		setPower(getPower() + timeFrameDatacenterEnergy);

		checkCloudletCompletion();

		/** Remove completed VMs **/
		for (PowerHost host : this.<PowerHost> getHostList()) {
			for (Vm vm : host.getCompletedVms()) {
				System.out.println("The vm: " + vm.getId() + " is complete.  It's cloudlet is " + vm.getCloudletScheduler().getCloudletStatus(vm.getId()));
				pauseTest();
				getVmAllocationPolicy().deallocateHostForVm(vm);
				getVmList().remove(vm);
				System.out.println("The vms state history size is: " + vm.getStateHistory().size());
				Log.printLine("VM #" + vm.getId() + " has been deallocated from host #" + host.getId());
			}
		}

		Log.printLine();
		//Use of the write method to append the row to the file
		WriteResultsToFile(DataMatrix);
		setLastProcessTime(currentTime);
		return minTime;
	}
	
	/**
	 * Process the event for an User/Broker who wants to create a VM in this PowerDatacenter. This
	 * PowerDatacenter will then send the status back to the User/Broker.
	 * 
	 * @param ev a Sim_event object
	 * @param ack the ack
	 * @pre ev != null
	 * @post $none
	 */
	@Override
	protected void processVmCreate(SimEvent ev, boolean ack) {
		Vm vm = (Vm) ev.getData();
			//Places on vmToPeLocList
		for(Map<String, Object> vmToLoc: GameTheoryRunner.getTranslator().getVmIdToNewAnimalLocList()) {
			if(vm.getId()==(int) vmToLoc.get("vm")) {
				vmIdToPeLocList.add(vmToLoc);
			}
		}
//		System.out.println("In process vm create");
		boolean result = getVmAllocationPolicy().allocateHostForVm(vm);
			
		if (ack) {
			int[] data = new int[3];
			data[0] = getId();
			data[1] = vm.getId();

			if (result) {
				data[2] = CloudSimTags.TRUE;
			} else {
				data[2] = CloudSimTags.FALSE;
			}
			send(vm.getUserId(), CloudSim.getMinTimeBetweenEvents(), CloudSimTags.VM_CREATE_ACK, data);
		}

		if (result) {
			getVmList().add(vm);

			if (vm.isBeingInstantiated()) {
				vm.setBeingInstantiated(false);
			}
			vm.updateVmProcessing(CloudSim.clock(), getVmAllocationPolicy().getHost(vm).getVmScheduler()
					.getAllocatedMipsForVm(vm));
		}
	}

	
	/**
	 * Destroys the hacked virtual machines
	 * 
	 * @param ev a Sim_event object
	 * @pre ev != null
	 * @post $none
	 */
	void queueHackedCloudlets(){
		List<Map<String, Object>> vmIdToDeadAnimalLocList = GameTheoryRunner.getTranslator().getVmIdToDeadAnimalLocList();
		ArrayList<Map<String, Object>> newPauseCloudletList = new ArrayList<Map<String,Object>>();
//		System.out.println("[pauseHackedCloudlets] Press enter to continue");
//		try{System.in.read();}
//		catch(Exception e){}
		final double[] DataMatrix = new double[vmIdToDeadAnimalLocList.size()+1];
		DataMatrix[0]=CloudSim.clock();
		int i = 1;
			for ( Map<String, Object> vmToDeadAnimalLoc : vmIdToDeadAnimalLocList) {
			int vmId = (int) vmToDeadAnimalLoc.get("vm");
			DataMatrix[i]=vmId;
			for(Vm vm : getVmList() ) {
				if(vm.getId()==vmId) {
					int idx = 0;
					// code to remove the vm and animal location in the vmToPeLocList
					Iterator<Map<String, Object>> it = pauseCloudletList.iterator(); 
					while (it.hasNext()) {
						Map<String,Object> pauseCloudlet = it.next();
						Cloudlet cl = (Cloudlet) pauseCloudlet.get("cloudlet");
						if((int) cl.getVmId()== vm.getId()){
							pauseCloudlet.put("pause", timePeriodCount);;
							cl.setVmId(-1);;
							it.remove();
							newPauseCloudletList.add(pauseCloudlet);
							sendNow(vm.getUserId(), CloudSimTags.CLOUDLET_RETURN, cl);
						}
						}
					GameTheoryRunner.getBroker().getVmList().remove(vm);
					GameTheoryRunner.getBroker().getVmsToDatacentersMap().remove(vmId); 
			sendNow(getId(), CloudSimTags.VM_DESTROY, vm);
			}
			}
			i++;	
			}//end for
//			System.out.println("[pauseHackedCloudlets] The hacked vms are: " + vmIdToDeadAnimalLocList.size());
//			System.out.println("[pauseHackedCloudlets] The active vms are: " + activeCloudletList.size());
//			System.out.println("The cloudlets returned to the Broker are: " + newPauseCloudletList.size() + ". Press enter to continue");
//			try{System.in.read();}
//			catch(Exception e){}
			WriteDestroyedVmsToFile(DataMatrix);
	}
	
	/**
	 * Process the event for an User/Broker who wants to destroy a VM previously created in this
	 * PowerDatacenter. This PowerDatacenter may send, upon request, the status back to the
	 * User/Broker.
	 * 
	 * @param ev a Sim_event object
	 * @param ack the ack
	 * @pre ev != null
	 * @post $none
	 */
	protected void processVmDestroy(SimEvent ev, boolean ack) {
		Vm vm = (Vm) ev.getData();
//	System.out.println("\nThe d/c called deallocateHostForVM using "+ getVmAllocationPolicy().getClass() + " for host " + getVmAllocationPolicy().getHost(vm).getVmsMigratingIn());
		getVmAllocationPolicy().deallocateHostForVm(vm);
	//removes on vmToPeLocList
	for(Map<String, Object> vmToLoc: GameTheoryRunner.getTranslator().getVmIdToDeadAnimalLocList()) {
		if(vm.getId()==(int) vmToLoc.get("vm")) {
			vmIdToPeLocList.remove(vmToLoc);
			System.out.println(CloudSim.clock() + "[processVmDestroy] vm " +vm.getId() + " removed from the pvToPeLocList.");
		}
	}
		if (ack) {
			int[] data = new int[3];
			data[0] = getId();
			data[1] = vm.getId();
			data[2] = CloudSimTags.TRUE;

			sendNow(vm.getUserId(), CloudSimTags.VM_DESTROY_ACK, data);
		}
				
		getVmList().remove(vm);
		SimEvent event1 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_DESTROY));
		SimEvent event2 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_DESTROY_ACK));
//		if ((event1 == null && event2 == null)) {
//			System.out.println("the deffered queue has no vms to destroy at: " + CloudSim.clock() +" Press enter to continue");
//			try{System.in.read();}
//			        catch(Exception e){}
//		}
	}
	/**
	 * Process the event for an User/Broker who wants to migrate a VM. This PowerDatacenter will
	 * then send the status back to the User/Broker.
	 * 
	 * @param ev a Sim_event object
	 * @pre ev != null
	 * @post $none
	 */
	@Override
	protected void processVmMigrate(SimEvent ev, boolean ack) {
		updateCloudetProcessingWithoutSchedulingFutureEvents();
		boolean result = false;
		Object tmp = ev.getData();
		if (!(tmp instanceof Map<?, ?>)) {
			throw new ClassCastException("The data object must be Map<String, Object>");
		}

		@SuppressWarnings("unchecked")
		Map<String, Object> migrate = (HashMap<String, Object>) tmp;
		Vm vm = (Vm) migrate.get("vm");
		Host host = (Host) migrate.get("host");
		
		if(host.getId()==vm.getHost().getId()) {
			host.getVmScheduler().getVmsMigratingIn().add(vm.getUid());
			host.getVmScheduler().getVmsMigratingOut().add(vm.getUid());
		}
//			System.out.println("[processVmMigrate] The pes before pe deallocation are: " + host.getVmScheduler().getPesAllocatedForVM(vm));
//			host.getVmScheduler().deallocatePesForVm(vm);
//			System.out.println("[processVmMigrate] The pes after pe deallocation are: " + host.getVmScheduler().getPesAllocatedForVM(vm));
				
//			Iterator<Map<String, Object>> it = vmIdToPeLocList.iterator(); 
//			while (it.hasNext()) {
//			Map<String,Object> vmIdToPeLoc = it.next();
//			if((int)vmIdToPeLoc.get("vm")== vm.getId()){
//				System.out.println("The vm is being moved from location: " + vmIdToPeLoc.get("animal"));
//			it.remove();;}
//			}
	// code to place the vm and animal location in the vmToPeLocList
//			for(Map<String, Object> vmIdToAnimalLoc: GameTheoryRunner.getTranslator().getVmIdToMovedAnimalLocList()) {
//				if(vm.getId()==(int) vmIdToAnimalLoc.get("vm")) {
////					System.out.println("The vm is being moved to location: " + vmIdToAnimalLoc.get("animal"));
//					vmIdToPeLocList.add(vmIdToAnimalLoc);
//				}
//			}//end for
//			vm.setInMigration(false);
//			result = host.getVmScheduler().allocatePesForVm(vm, vm.getCurrentRequestedMips());
//			System.out.println("[processVmMigrate] The pes after allocation are: " + host.getVmScheduler().getPesAllocatedForVM(vm));
//			try{System.in.read();}
//		    catch(Exception e){}	
//			host.removeMigratingInVm(vm);	
//			host.getVmScheduler().getVmsMigratingIn().remove(vm.getUid());
//			host.getVmScheduler().getVmsMigratingOut().remove(vm.getUid());
//		}else {
		getVmAllocationPolicy().deallocateHostForVm(vm);
//		System.out.println("[processVmMigrate] Vm: " + vm.getId() + " is in migration to host " + host.getId() + ".  Its migrations are:");
//		for (Vm tmpvm: host.getVmList()) { 
//		System.out.println("[host.getVmList]: " + tmpvm.getId() + " is in migration: " + tmpvm.isInMigration() + ", migrating in at host: " + host.getVmsMigratingIn().contains(tmpvm));
//		System.out.println("At the vmScheduler: migrating in: " + host.getVmScheduler().getVmsMigratingIn().contains(tmpvm.getUid()) + " and out " + host.getVmScheduler().getVmsMigratingOut().contains(tmpvm.getUid()));}
//		System.out.println("Press enter to continue");
//		try{System.in.read();}
//		       catch(Exception e){}
		host.removeMigratingInVm(vm);  
		result = getVmAllocationPolicy().allocateHostForVm(vm, host);

		host.getVmScheduler().getVmsMigratingIn().remove(vm.getUid());
		host.getVmScheduler().getVmsMigratingOut().remove(vm.getUid());
				// code to remove the vm and animal location in the vmToPeLocList
	Iterator<Map<String, Object>> it = vmIdToPeLocList.iterator(); 
		while (it.hasNext()) {
		Map<String,Object> vmToPeLoc = it.next();
		if((int)vmToPeLoc.get("vm")== vm.getId()){
		it.remove();;
			}
		}
// code to place the vm and animal location in the vmToPeLocList
		for(Map<String, Object> vmToLoc: GameTheoryRunner.getTranslator().getVmIdToMovedAnimalLocList()) {
			if(vm.getId()==(int) vmToLoc.get("vm")) {
				vmIdToPeLocList.add(vmToLoc);	}
			vm.setInMigration(false);
		}//end for
//		}//end else
		
		if (!result) {
			Log.printLine("[Datacenter.processVmMigrate] VM allocation to the destination host failed");
			System.exit(0);
		}
		if (ack) {
			int[] data = new int[3];
			data[0] = getId();
			data[1] = vm.getId();

			if (result) {
				data[2] = CloudSimTags.TRUE;
			} else {
				data[2] = CloudSimTags.FALSE;
			}
			sendNow(ev.getSource(), CloudSimTags.VM_CREATE_ACK, data);
		}

		Log.formatLine(
				"%.2f: Migration of VM #%d to Host #%d is completed",
				CloudSim.clock(),
				vm.getId(),
				host.getId());
//		vm.setInMigration(false);
		


		SimEvent event = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_MIGRATE));
		if (event == null || event.eventTime() > CloudSim.clock()) {
			updateCloudetProcessingWithoutSchedulingFutureEventsForce();
		}
	}

	@Override
	protected void processCloudletSubmit(SimEvent ev, boolean ack) {
		super.processCloudletSubmit(ev, ack);
		Cloudlet cl = (Cloudlet) ev.getData();
		int vmId = cl.getVmId();
        Map<String, Object> vmCloudlet= new  HashMap<String, Object>();
        vmCloudlet.put("vm", vmId);
        vmCloudlet.put("cloudlet", cl);
        Map<String, Object> pauseCloudlet= new  HashMap<String, Object>();
        pauseCloudlet.put("pause", 0);
        pauseCloudlet.put("cloudlet", cl);
        pauseCloudletList.add(pauseCloudlet);
		setCloudletSubmitted(CloudSim.clock());
		}

	/**
	 * Gets the power.
	 * 
	 * @return the power
	 */
	public double getPower() {
		return power;
	}

	/**
	 * Sets the power.
	 * 
	 * @param power the new power
	 */
	protected void setPower(double power) {
		this.power = power;
	}

	/**
	 * Checks if PowerDatacenter is in migration.
	 * 
	 * @return true, if PowerDatacenter is in migration; false otherwise
	 */
	protected boolean isInMigration() {
		boolean result = false;
		for (Vm vm : getVmList()) {
			if (vm.isInMigration()) {
				result = true;
				break;
			}
		}
		return result;
	}

	/**
	 * Checks if migrations are disabled.
	 * 
	 * @return true, if  migrations are disable; false otherwise
	 */
	public boolean isDisableMigrations() {
		return disableMigrations;
	}

	/**
	 * Disable or enable migrations.
	 * 
	 * @param disableMigrations true to disable migrations; false to enable
	 */
	public void setDisableMigrations(boolean disableMigrations) {
		this.disableMigrations = disableMigrations;
	}

	/**
	 * Checks if is cloudlet submited.
	 * 
	 * @return true, if is cloudlet submited
	 */
	protected double getCloudletSubmitted() {
		return cloudletSubmitted;
	}

	/**
	 * Sets the cloudlet submitted.
	 * 
	 * @param cloudletSubmitted the new cloudlet submited
	 */
	protected void setCloudletSubmitted(double cloudletSubmitted) {
		this.cloudletSubmitted = cloudletSubmitted;
	}

	/**
	 * Gets the migration count.
	 * 
	 * @return the migration count
	 */
	public int getMigrationCount() {
		return migrationCount;
	}

	/**
	 * Sets the migration count.
	 * 
	 * @param migrationCount the new migration count
	 */
	protected void setMigrationCount(int migrationCount) {
		this.migrationCount = migrationCount;
	}

	/**
	 * Increment migration count.
	 */
	protected void incrementMigrationCount() {
		setMigrationCount(getMigrationCount() + 1);
	}
	/**
	 * Gets the time period count.
	 * 
	 * @return the time period count
	 */
	public int getTimePeriodCount() {
		return timePeriodCount;
	}
	/**
	 * Sets the time period count.
	 * 
	 * @param timePeriodCount the new migration count
	 */
	private void setTimePeriodCount(int timePeriodCount) {
		this.timePeriodCount = timePeriodCount;
		}
	/**
	 * Increment time period count.
	 */
	protected void incrementTimePeriodCount() {
		setTimePeriodCount(getTimePeriodCount() + 1);
	}
	
	// The method to write results to external file
	private static void WriteResultsToFile(double[] results){
		//create a file writer
		FileWriter fw;
		try {
	/** Constructs a FileWriter object given a File object.
	Pass true as second parameter to the constructor of FileWriter to instruct the writer to append the data 
	instead of rewriting the file. */
			fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\GameTheory.csv", true); 
			try (PrintWriter pw = new PrintWriter(fw)) {
	//Writes the number of columns, the range of the DataMatrix
	for(int i = 0; i < results.length; i++){
	pw.print(results[i]);
	//to separate the values by comma, when opened in .txt format.
	pw.print(",");
	}
	pw.println();
	//Flush the output to the file
	pw.flush();
	//Close the Print Writer
	pw.close();
	}
	//Close the File Writer
	fw.close();
//Marker for writing to output file.
//	System.out.println("Successfully wrote to the file.");
	} catch (IOException e) {
	}
	}
	
	// The method to write results to external file
		private static void WriteDestroyedVmsToFile(double[] dataMatrix){
			
			FileWriter fw;
			try {
				fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\DestroyedVms.csv", true); 
			try (PrintWriter pw = new PrintWriter(fw)) {
			for(int i = 0; i < dataMatrix.length; i++){
				pw.print(dataMatrix[i]);
				pw.print(",");
				}
		pw.println();
		pw.flush();
		pw.close();
		}
		fw.close();
		} catch (IOException e) {}
		}
	/** Returns the ListMap of the virtural machines to their locations in the landscape
	 * 
	 * @return vmToPeLocList
	 */
	public List<Map<String, Object>> getVmToPeLocList()
	{
		return vmIdToPeLocList;
	}
	
}