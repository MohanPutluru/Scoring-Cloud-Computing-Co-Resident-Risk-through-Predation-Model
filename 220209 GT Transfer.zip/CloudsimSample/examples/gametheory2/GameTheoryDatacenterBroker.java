/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package gametheory2;

import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.lists.VmList;
import org.cloudbus.cloudsim.power.PowerDatacenterBroker;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerDynamicWorkload;

/**
 * A broker for the power package.
 * 
 *  */
public class GameTheoryDatacenterBroker extends PowerDatacenterBroker {

	/**
	 * Instantiates a new power datacenter broker.
	 * 
	 * @param name the name
	 * @throws Exception the exception
	 */
	
	/** The newVms created list. */
	protected List<? extends Vm> newVmList;

	/** The cloudlet list. */
	protected List<? extends Cloudlet> newCloudletList;

	public GameTheoryDatacenterBroker(String name) throws Exception {
		super(name);
	}

	/**
	 * Processes events available for this Broker.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != null
	 * @post $none
	 */
	@Override
	public void processEvent(SimEvent ev) {
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.RESOURCE_CHARACTERISTICS_REQUEST:
				processResourceCharacteristicsRequest(ev);
				break;
			// Resource characteristics answer
			case CloudSimTags.RESOURCE_CHARACTERISTICS:
				processResourceCharacteristics(ev);
				break;
			// VM Creation answer
			case CloudSimTags.VM_CREATE_ACK:
				processVmCreate(ev);
				break;
			// A finished cloudlet returned
			case CloudSimTags.CLOUDLET_RETURN:
				processCloudletReturn(ev);
				break;
			// if the simulation finishes
			case CloudSimTags.END_OF_SIMULATION:
				shutdownEntity();
				break;
			// other unknown tags are processed by this method
			default:
				processOtherEvent(ev);
				break;
		}
	}
	/*
	 * (non-Javadoc)
	 * @see
	 * org.cloudbus.cloudsim.DatacenterBroker#processVmCreate(org.cloudbus.cloudsim.core.SimEvent)
	 */
	@Override
	protected void processVmCreate(SimEvent ev) {
		int[] data = (int[]) ev.getData();
		int datacenterId = data[0];
		int vmId = data[1];
		int result = data[2];

		if (result != CloudSimTags.TRUE) {
			System.out.println(CloudSim.clock() + ": " + getName() + ": Creation of VM #" + vmId
					+ " failed in Datacenter #" + datacenterId);
			System.exit(0);
		}
			System.out.println("DataCenterBroker[processVmCreate] The vm id is " + vmId + " and its result is " + result);
		
			if (result == CloudSimTags.TRUE) {
				getVmsToDatacentersMap().put(vmId, datacenterId);
				getVmsCreatedList().add(VmList.getById(getVmList(), vmId));

				Log.printLine(CloudSim.clock() + ": " + getName() + ": VM #" + vmId
						+ " has been created in Datacenter #" + datacenterId + ", Host #"
						+ VmList.getById(getVmsCreatedList(), vmId).getHost().getId());
			} else {
				Log.printLine(CloudSim.clock() + ": " + getName() + ": Creation of VM #" + vmId
						+ " failed in Datacenter #" + datacenterId);
			}

			incrementVmsAcks();
//			System.out.println("[processVmCreate]: The VMs acks is: "+ getVmsAcks() + " Press enter to continue");
//			try{System.in.read();}
//			        catch(Exception e){}
			
			// all the requested VMs have been created
			if (getVmsCreatedList().size() == getVmList().size() - getVmsDestroyed()) {
				System.out.println("SUBMIT through getVmsCreatedList().size() == getVmList().size() - getVmsDestroyed()");
				System.out.println("The cloudlet list size is " + getCloudletList().size());
				submitCloudlets();
			} else if (getVmsRequested() == getVmsAcks()) {
					// find id of the next datacenter that has not been tried
					for (int nextDatacenterId : getDatacenterIdsList()) {
						if (!getDatacenterRequestedIdsList().contains(nextDatacenterId)) {
							createVmsInDatacenter(nextDatacenterId);
							return;
						}
					}//end for

					// all datacenters already queried
					if (newVmList.size() > 0 && getCloudletList().size()>0) { // if some new vms were created and there are cloudlets
	System.out.println("[processVmCreate] The newVmList is: " + newVmList.size() + " and getCloudletList() is: " + getCloudletList().size() + " Press enter to continue");
	try{System.in.read();}
	catch(Exception e){}
						submitCloudlets();
					} else { // no vms created. abort
						Log.printLine(CloudSim.clock() + ": " + getName()
								+ ": none of the required VMs could be created. Aborting");
						finishExecution();
					}
			}
		}
	/**
	 * submitCloudlets for GameTheory
	 */
	@Override
	public void submitCloudlets() {
//		System.out.println("[submitCloudlets]: Inside the GameTheoryDatacenterBroker. Press enter to continue");
//		try{System.in.read();}
//		        catch(Exception e){}
		int pausedCloudletIdx = 0;
		for (Cloudlet cloudlet : getCloudletList()) {
			Vm vm;
			// if this cloudlet is a return
			if (cloudlet.getVmId() == -1 && newVmList.size()<pausedCloudletIdx) {
				int clId = cloudlet.getCloudletId();
				vm = newVmList.get(pausedCloudletIdx);
				System.out.println("Attempt to bind a cloudlet " + clId + " to vm " + vm.getId());
				cloudlet.setVmId(vm.getId());
//				newVmList.remove(0);
				pausedCloudletIdx = pausedCloudletIdx + 1;
				System.out.println(pausedCloudletIdx);
			} else { // submit to the specific vm
				vm = VmList.getById(getVmsCreatedList(), cloudlet.getVmId());
				if (vm == null) { // vm was not created
					Log.printLine(CloudSim.clock() + ": " + getName() + ": Postponing execution of cloudlet "
							+ cloudlet.getCloudletId() + ": bount VM not available");
					continue;
				}
			}
			Log.printLine(CloudSim.clock() + ": " + getName() + ": Sending cloudlet "
					+ cloudlet.getCloudletId() + " to VM #" + vm.getId());
			cloudlet.setVmId(vm.getId());
			sendNow(getVmsToDatacentersMap().get(vm.getId()), CloudSimTags.CLOUDLET_SUBMIT, cloudlet);
			cloudletsSubmitted++;
			getCloudletSubmittedList().add(cloudlet);
		}
		// remove submitted cloudlets from waiting list
		for (Cloudlet cloudlet : getCloudletSubmittedList()) {
			getCloudletList().remove(cloudlet);
		}
//		System.out.println("[submitCloudlets]: The  number of unsubmitted cloudlets is: " + getCloudletList().size() + ".  Press enter to continue");
//		try{System.in.read();}
//	    catch(Exception e){}
	} // End of submitDesignatedCloudlets()
	
	/**
	 * Process a cloudlet return event.
	 * 
	 * @param ev a SimEvent object
	 * @pre ev != $null
	 * @post $none
	 */
	@Override
	protected void processCloudletReturn(SimEvent ev) {
		Cloudlet cloudlet = (Cloudlet) ev.getData();
		getCloudletReceivedList().add(cloudlet);
		cloudletsSubmitted--;
		getCloudletSubmittedList().remove(cloudlet);
		getCloudletList().add(cloudlet);
//		System.out.println("[processCloudletReturn]: The cloudlet returned is: " + cloudlet.getCloudletId() + ".  Press enter to continue");
//		try{System.in.read();}
//	    catch(Exception e){}
		if (getCloudletList().size() == 0 && cloudletsSubmitted == 0) { // all cloudlets executed
			Log.printLine(CloudSim.clock() + ": " + getName() + ": All Cloudlets executed. Finishing...");
			clearDatacenters();
			finishExecution();
		} else { // some cloudlets haven't finished yet
			if (getCloudletList().size() > 0 && cloudletsSubmitted == 0) {
				// all the cloudlets sent finished. It means that some bount
				// cloudlet is waiting its VM be created
				clearDatacenters();
				createVmsInDatacenter(0);
			}

		}
	}
	/**
	 * This method is used to send to the broker the list of new virtual machines that must be
	 * created.
	 * 
	 * @param list the list
	 * @pre list !=null
	 * @post $none
	 */
	public void submitNewVmList(List<Vm> list) {
		if(newVmList != null) {
			newVmList.clear();
		}
		getVmList().addAll(list);
		newVmList = list;
	} 
	
	/**
	 * This method sets a new list of cloudlets.
	 * 
	 * @param list the list
	 * @pre list !=null
	 * @post $none
	 */
	public void submitNewCloudletList(List<? extends Cloudlet> list) {
		if(newCloudletList!=null) {
		newCloudletList.clear();
		}
//		for (Cloudlet cloudlet : list) {
//			newCloudletList.add(cloudlet);
//		}
		newCloudletList = list;
//	System.out.println("The cloudlet list from inside the broker is " + getCloudletList());
	}
	/**
	 * new VM creation.
	 */
	public void newVmsCreate() {
//		System.out.println("[newVmsCreate]: cloudlet and vm list sizes are "+ cloudletList.size() + " and " + newVmList.size() + " Press enter to continue");
//	try{System.in.read();}
//		        catch(Exception e){}
		final double[] DataMatrix = new double[1+newVmList.size()];
		DataMatrix[0]=CloudSim.clock();
		int requestedVms = 0;
		int datacenterId = getDatacenterIdsList().get(getDatacenterIdsList().size()-1);
		for (Vm vm : newVmList) {
			int vmId = vm.getId();
			DataMatrix[newVmList.indexOf(vm)+1]=vmId;
			getVmsToDatacentersMap().put(vmId, datacenterId);
			getVmsCreatedList().add(VmList.getById(getVmList(), vmId)); //may need to be vmList
			Log.printLine(CloudSim.clock() + ": " + getName() + ": Trying to Create VM #" + vm.getId()
			+ " in " + CloudSim.getEntityName(datacenterId));
			sendNow(datacenterId, CloudSimTags.VM_CREATE_ACK, vm);
			requestedVms++;
			}
		WriteNewVmsToFile(DataMatrix);
		setVmsRequested(getVmsRequested()+ requestedVms);
	}
	public void newVmsCloudletsSubmit() {
		int datacenterId = getDatacenterIdsList().get(getDatacenterIdsList().size()-1);
		for (Vm vm: newVmList) {
		for (Cloudlet cloudlet : cloudletList) {
		Log.printLine(CloudSim.clock() + ": " + getName() + ": Sending cloudlet "
				+ cloudlet.getCloudletId() + " to VM #" + vm.getId());
		cloudlet.setVmId(vm.getId());
		sendNow(datacenterId, CloudSimTags.CLOUDLET_SUBMIT, cloudlet);
		cloudletsSubmitted++;
		getCloudletSubmittedList().add(cloudlet);
		}
		}
	}
	
	// The method to write results to external file
	private static void WriteResultsToFile(double[] dataMatrix){
		//create a file writer
		FileWriter fw;
		try {
	/** Constructs a FileWriter object given a File object.
	Pass true as second parameter to the constructor of FileWriter to instruct the writer to append the data 
	instead of rewriting the file. */
			fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\BrokerData.csv", true); 
			try (PrintWriter pw = new PrintWriter(fw)) {
	//Writes the number of columns, the range of the DataMatrix
	for(int i = 0; i < dataMatrix.length; i++){
		pw.print(dataMatrix[i]);
		//to separate the values by comma, when opened in .txt format.
		pw.print(",");
		}
	pw.println();
	//Flush the output to the file
	pw.flush();
	//Close the Print Writer
	pw.close();
	}
	//Close the File Writer
	fw.close();
//Marker for writing to output file.
//	System.out.println("Successfully wrote to the file.");
	} catch (IOException e) {}
	}
	// The method to write results to external file
	private static void WriteNewVmsToFile(double[] dataMatrix){
		
		FileWriter fw;
		try {
			fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\NewVms.csv", true); 
		try (PrintWriter pw = new PrintWriter(fw)) {
		for(int i = 0; i < dataMatrix.length; i++){
			pw.print(dataMatrix[i]);
			pw.print(",");
			}
	pw.println();
	pw.flush();
	pw.close();
	}
	fw.close();
	} catch (IOException e) {}
	}
}
