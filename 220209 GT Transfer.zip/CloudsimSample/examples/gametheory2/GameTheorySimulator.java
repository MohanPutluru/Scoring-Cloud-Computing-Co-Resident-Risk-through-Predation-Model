package gametheory2;

import java.util.Random;
import java.util.Scanner;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Math;


import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.Pe;

import predprey.Field;
import predprey.Location;
import predprey.Randomizer;
import predprey.SimulatorView;
/**
 * A simple predator-prey simulator, based on a rectangular field containing 
 * rabbits and foxes.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 */
public class GameTheorySimulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
//    private static final int DEFAULT_WIDTH = 5; //ZeroTrustField adapted from 300
//    // The default depth of the grid.
//    private static final int DEFAULT_DEPTH = 5; //ZeroTrustField adapted from 60
//    private static final int DEFAULT_WIDTH = 96;
//    private static final int DEFAULT_DEPTH =  64;
	private static final int PROP_CONST = 2;
    private static final int DEFAULT_DEPTH =  16*PROP_CONST;
    private static final int DEFAULT_WIDTH = 16*PROP_CONST;
    private static final double FOX_CREATION_PROBABILITY = 0.015*.93;
    private static final double RABBIT_CREATION_PROBABILITY = 0.60*.93;

    private static final int DELAY = 0;

    // Lists of animals in the field.
    private List<GameTheoryRabbit> rabbits;
    private List<GameTheoryFox> foxes;
      // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    // maps vms to animal locations
    private List<Map<String, Object>> vmIdToAnimalLocList;
    // maps vm to dead animals
    private List<Map<String, Object>> vmIdToDeadAnimalLocList;
    // maps vm to new animals
    private List<Map<String, Object>> vmIdToNewAnimalLocList;
    // maps vm to moved animals
    private List<Map<String, Object>> vmIdToMovedAnimalLocList;
   // rabbits hunted in a step
    private int huntedRabbits;

	/**
     * Construct a simulation field with default size.
     */
    public GameTheorySimulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public GameTheorySimulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be >= zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        rabbits = new ArrayList<>();
        foxes = new ArrayList<>();
        field = new Field(depth, width);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(GameTheoryRabbit.class, Color.ORANGE);
        view.setColor(GameTheoryFox.class, Color.BLUE);
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long 
     * period (4000 steps).
     */
    public void runLongSimulation()
    {
        simulate(4000);
    }
    
    /**
     * Run the simulation for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step=1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
             delay(DELAY);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step. Iterate
     * over the whole field updating the state of each fox and rabbit.
     * Return is the new vmToAnimalList
     */
    public List<Map<String, Object>>  simulateOneStep()
    {
    	huntedRabbits = 0;
        List<Map<String, Object>>  vmIdToNewAnimalLocList = new LinkedList<Map<String, Object>>();
        List<Map<String, Object>>  vmIdToDeadAnimalLocList = new LinkedList<Map<String, Object>>();
    	List<Map<String, Object>>  vmIdToMovedAnimalLocList = new LinkedList<Map<String, Object>>();
        step++;
        
        // Provide space for newborn rabbits and dead rabbits.
        List<GameTheoryRabbit> newRabbits = new ArrayList<>();        
        List<GameTheoryRabbit> deadRabbits = new ArrayList<>();
        List<GameTheoryRabbit> movedRabbits = new ArrayList<>();
   // Let all rabbits act.
        for(Iterator<GameTheoryRabbit> it = getRabbits().iterator(); it.hasNext(); ) {
            GameTheoryRabbit rabbit = it.next();
            rabbit.run(newRabbits);
            if(! rabbit.isAlive()) {
// 	System.out.println("The rabbit " + rabbit.hashCode() + " is dead at " + rabbit.getLocation());
            	deadRabbits.add(rabbit);
                it.remove();
            }
            else {
            	movedRabbits.add(rabbit);  	
            }
        }
//        for(GameTheoryRabbit  it : newRabbits){
//        	System.out.println("The new rabbit: " + it.hashCode() + " has location " + it.getLocation());
//        }
        
        getRabbits().addAll(newRabbits);    
        view.showStatus(step, field);
 //       delay(1000);
        
        // Provide space for newborn foxes and dead foxes.
        List<GameTheoryFox> newFoxes = new ArrayList<>();        
        List<GameTheoryFox> deadFoxes = new ArrayList<>();  
        List<GameTheoryFox> movedFoxes = new ArrayList<>();  
        
        // Let all foxes act.
        for(Iterator<GameTheoryFox> it = foxes.iterator(); it.hasNext(); ) {
            GameTheoryFox fox = it.next();
//          System.out.println(("The fox id and location is: " + fox.hashCode()+ ", and " + fox.getLocation()));
            fox.hunt(newFoxes);
            huntedRabbits = huntedRabbits + fox.getHuntedRabbits();
            if(! fox.isAlive()) {
            	deadFoxes.add(fox);
                it.remove();
            }
            else {
            	movedFoxes.add(fox);
            }
        }
                
        foxes.addAll(newFoxes);
        view.showStatus(step, field);
        delay(DELAY);
        
        //code to add the dead rabbits from the fox run to the list of dead rabbits
        for(Iterator<GameTheoryRabbit> it = getRabbits().iterator(); it.hasNext(); ) {
            GameTheoryRabbit rabbit = it.next();
            if(! rabbit.isAlive()) {
//  System.out.println("The rabbit " + rabbit.hashCode() + " is dead at " + rabbit.getLocation());
            	deadRabbits.add(rabbit);
                it.remove();
            }
        }
        
      //code to remove dead rabbits from moved rabbits after the fox hunts
        for(Iterator<GameTheoryRabbit> it = movedRabbits.iterator(); it.hasNext(); ) {
            GameTheoryRabbit rabbit = it.next();
            if(! rabbit.isAlive()) {
                it.remove();
            }
        }
        
      //code to remove dead rabbits from new rabbits after the fox hunts
        for(Iterator<GameTheoryRabbit> it = newRabbits.iterator(); it.hasNext(); ) {
            GameTheoryRabbit rabbit = it.next();
            if(! rabbit.isAlive()) {
                it.remove();
            }
        }
//code to produce list of hash codes of moved animals and location Cloudsim to remove
        for(GameTheoryRabbit rabbit : movedRabbits) {
            Map<String, Object> movedRabbit= new  HashMap<String, Object>();
            if(rabbit.getLocation() != null) {
            movedRabbit.put("vm", rabbit.hashCode());
            movedRabbit.put("animal", rabbit.getLocation());
//   System.out.println("The rabbit " + rabbit.hashCode() + " is moved to  " + rabbit.getLocation());
            vmIdToMovedAnimalLocList.add(movedRabbit);
            }
        }
        for(GameTheoryFox fox : movedFoxes) {
            Map<String, Object> movedFox = new  HashMap<String, Object>();
            movedFox.put("vm", fox.hashCode());
            movedFox.put("animal", fox.getLocation());
            vmIdToMovedAnimalLocList.add(movedFox);
            }
 
  //code to produce list of hash codes of dead animals and location Cloudsim to remove
        for(GameTheoryRabbit rabbit : deadRabbits) {
            Map<String, Object> deadRabbit= new  HashMap<String, Object>();
            deadRabbit.put("vm", rabbit.hashCode());
            deadRabbit.put("animal", rabbit.getLocation());
            vmIdToDeadAnimalLocList.add(deadRabbit);
            }
        for(GameTheoryFox fox : deadFoxes) {
            Map<String, Object> deadFox = new  HashMap<String, Object>();
            deadFox.put("vm", fox.hashCode());
            deadFox.put("animal", fox.getLocation());
            vmIdToDeadAnimalLocList.add(deadFox);
            }
   

        setVmIdToDeadAnimalLocList(vmIdToDeadAnimalLocList);
        setVmToMovedAnimalLocList(vmIdToMovedAnimalLocList);
//   System.out.println("The moved animals inside of ZeroTrustSimulator are " + getVmIdToMovedAnimalLocList());   
//   System.out.println("The dead animals inside of ZeroTrustSimulator are " + getVmIdToDeadAnimalLocList());
        
//Code to make new vm hashcode and animal list
        for(GameTheoryRabbit rabbit : newRabbits) {
            Map<String, Object> vmIdToNewAnimalLoc= new  HashMap<String, Object>();
        	vmIdToNewAnimalLoc.put("vm", rabbit.hashCode());
        	vmIdToNewAnimalLoc.put("animal", rabbit.getLocation());
        	vmIdToNewAnimalLocList.add(vmIdToNewAnimalLoc);
        }
        for(GameTheoryFox fox : newFoxes) {
            Map<String, Object> vmIdToNewAnimalLoc= new  HashMap<String, Object>();
            vmIdToNewAnimalLoc.put("vm", fox.hashCode());
            vmIdToNewAnimalLoc.put("animal", fox.getLocation());
            vmIdToNewAnimalLocList.add(vmIdToNewAnimalLoc);
            }
//	System.out.println("\nThe new animals inside of ZeroTrustSimulator are " + vmIdToNewAnimalLocList);
        setVmIdToNewAnimalLocList(vmIdToNewAnimalLocList);
        
//	Code to update the vm to animal location list
        vmIdToAnimalLocList.clear();
        for(GameTheoryRabbit rabbit : getRabbits()) {
            Map<String, Object> vmIdToAnimalLoc= new  HashMap<String, Object>();
            vmIdToAnimalLoc.put("vm", rabbit.hashCode());
            vmIdToAnimalLoc.put("animal", rabbit.getLocation());
            vmIdToAnimalLocList.add(vmIdToAnimalLoc);
        }
        for(GameTheoryFox fox : foxes) {
            Map<String, Object> vmIdToAnimalLoc= new  HashMap<String, Object>();
            vmIdToAnimalLoc.put("vm", fox.hashCode());
            vmIdToAnimalLoc.put("animal", fox.getLocation());
            vmIdToAnimalLocList.add(vmIdToAnimalLoc);
            }
//   System.out.println("\n The vmIdToAnimalLocList is: " + vmIdToAnimalLocList + "\n");
        setVmIdToAnimalLocList(vmIdToAnimalLocList);
                final double[] DataMatrix = new double[3];
		DataMatrix[0]=step;
		DataMatrix[1]=foxes.size();
		DataMatrix[2]=rabbits.size();
		WriteResultsToFile(DataMatrix);
		
//		System.out.println("GameTheorySimulator, simulateOneStep() Press \"ENTER\" to continue...");
//		@SuppressWarnings("resource")
//		Scanner scanner = new Scanner(System.in);
//		scanner.nextLine();
		
        return vmIdToNewAnimalLocList;
    }
    
    /**
	 * @return the huntedRabbits
	 */
	public int getHuntedRabbits() {
		return huntedRabbits;
	}

	/**
	 * @param huntedRabbits the huntedRabbits to set
	 */
	public void setHuntedRabbits(int huntedRabbits) {
		this.huntedRabbits = huntedRabbits;
	}

	/**
     * getters and setters for simulate one step
    	 */    
    public List<Map<String, Object>> getVmIdToDeadAnimalLocList() {
		return vmIdToDeadAnimalLocList;
	}
	public void setVmIdToDeadAnimalLocList(List<Map<String, Object>> vmToDeadAnimalLocList) {
		this.vmIdToDeadAnimalLocList = vmToDeadAnimalLocList;
	}
	public List<Map<String, Object>> getVmIdToMovedAnimalLocList() {
			return vmIdToMovedAnimalLocList;
		}
	public void setVmToMovedAnimalLocList(List<Map<String, Object>> vmToMovedAnimalLocList) {
			this.vmIdToMovedAnimalLocList = vmToMovedAnimalLocList;
		}
	 public    List<Map<String, Object>>  getVmIdToNewAnimalLocList() {
//		 	System.out.println("The getVmIdToAnimalLocList has " + vmIdToAnimalLocList);
				return vmIdToNewAnimalLocList;
			}
   	public void setVmIdToNewAnimalLocList(List<Map<String, Object>> vmIdToNewAnimalLocList) {
		this.vmIdToNewAnimalLocList = vmIdToNewAnimalLocList;
	}
	
	/**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        getRabbits().clear();
        foxes.clear();
        populate();
        // Show the starting state in the view.
        view.showStatus(step, field);
        delay(DELAY);
    }
    
     /**
     * Randomly populate the field with foxes and rabbits.
     * Returns the index with foxs and rabbits
     */
    private void populate()
    {
    	List<Map<String, Object>>  populatedVmIdToAnimalLocList = new LinkedList<Map<String, Object>>();
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= FOX_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    GameTheoryFox fox = new GameTheoryFox(true, field, location);
                    foxes.add(fox);
                }
                else if(rand.nextDouble() <= RABBIT_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    GameTheoryRabbit rabbit = new GameTheoryRabbit(true, field, location);
                    getRabbits().add(rabbit);
                }
                // List of Map of vms to animals
            }
        }
        for(GameTheoryRabbit rabbit : getRabbits()) {
            Map<String, Object> vmAnimal= new  HashMap<String, Object>();
            vmAnimal.put("vm", rabbit.hashCode());
            vmAnimal.put("animal", rabbit.getLocation());
            populatedVmIdToAnimalLocList.add(vmAnimal);
            }

         for(GameTheoryFox fox : foxes) {
                Map<String, Object> vmAnimal= new  HashMap<String, Object>();
                vmAnimal.put("vm", fox.hashCode());
                vmAnimal.put("animal", fox.getLocation());
                populatedVmIdToAnimalLocList.add(vmAnimal);
                }
            System.out.println("Landscape populated" );
 //           System.out.println("From inside the Simulator, the  vms  and locationss are: " + vmToAnimalList);
            setVmIdToAnimalLocList(populatedVmIdToAnimalLocList);
            setVmIdToNewAnimalLocList(populatedVmIdToAnimalLocList);
    }
    
 // This method is called for both populate and simulateOneStep
    public List<Map<String, Object>> getVmIdToAnimalLocList() {
		return vmIdToAnimalLocList;
	}
    public    void  setVmIdToAnimalLocList( List<Map<String, Object>>VmIdToAnimalLocList) {
		this.vmIdToAnimalLocList= VmIdToAnimalLocList;
	}
	
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    public void delay(int millisec)
    {
        try 
        {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) 
        {
            // wake up
        }
    }
    
    /**
     * Removes any dead animals from the rabbits and foxes lists.
     */
    private void removeDeadAnimals()
    {
        for (Iterator<GameTheoryFox> foxIt = foxes.iterator(); foxIt.hasNext();)
        {
            GameTheoryFox fox = foxIt.next();
            if (!fox.isAlive())
            {
                foxIt.remove();
            }
        }

        for (Iterator<GameTheoryRabbit> rabbitIt = getRabbits().iterator(); rabbitIt.hasNext();)
        {
            GameTheoryRabbit rabbit = rabbitIt.next();
            if (!rabbit.isAlive())
            {
                rabbitIt.remove();
            }
        }
   //getter for field to show object at a location     
    }
    public Field getField()
    {
        return field;
    }
    
  //getter for foxes to show foxes     
public List<GameTheoryFox> getFoxes()
{
    return foxes;
}
/**
 * assign vms to foxes and rabbits.
 */
public void reset(List<? extends Vm> vmList) {
	        step = 0;
	        getRabbits().clear();
	        foxes.clear();
	        populate(vmList);
	        // Show the starting state in the view.
	        view.showStatus(step, field);
	    }

/**
 * Deliberately populate the field with foxes and rabbits.
 */
private List<Map<String, Object>> populate(List<? extends Vm> vmList)
{
	List<Map<String, Object>>  vmToAnimalList = new LinkedList<Map<String, Object>>();
    field.clear();
 for(Vm vm : vmList) {
	 // ZeroTrustLocation of animal by its parallel hostId and placement by row and column
     int loc = vm.getHost().getId();
     int row = (int) (2*(Math.floor(loc/100)));
     int col = (int) (2*(Math.abs(loc-row*100/2)));
  // ZeroTrustLocation of animal by its parallel host pe hash and offset by row and column
     int ofstidx = 0;
     for (Pe pe: vm.getHost().getPeList()) {
    	 if (vm.getHost().getVmScheduler().getPesAllocatedForVM(vm).hashCode()==pe.hashCode()) {
    	 ofstidx++;}
     }
     row = (int) (row + Math.floor(ofstidx/2));
     col = (int) (col + Math.floor((ofstidx % 2)));
        Location location = new Location(row, col);
 //       System.out.println("The vm user id is " +(int) vm.getUid().charAt(0) +" which is differnt than " + ((int)'4'-1));
 //       System.out.println("The vm user id is " +vm.getUid().charAt(0));
        if( (int) vm.getUid().charAt(0) == (int)'3'-1) {
            
        GameTheoryFox fox = new GameTheoryFox(true, field, location);
        foxes.add(fox);
        
        // List of Map of vms to animals
        Map<String, Object> vmAnimal= new  HashMap<String, Object>();
        vmAnimal.put("vm", vm.getId());
        vmAnimal.put("animal", fox);
        vmToAnimalList.add(vmAnimal);
        }else {
        	GameTheoryRabbit rabbit = new GameTheoryRabbit(true, field, location);
            getRabbits().add(rabbit);
            Map<String, Object> vmAnimal= new  HashMap<String, Object>();
            vmAnimal.put("vm", vm.getId());
            vmAnimal.put("animal", rabbit);
            vmToAnimalList.add(vmAnimal);
        }
        }   
//System.out.println("The vm to animal list is " + vmToAnimalList);
return vmToAnimalList;
}

/**
 * clears the newAnimals list.
 * 
 *  */
public void clearNewAnimals(List<Map<String, Object>> vmToAnimalList) {
	vmToAnimalList.clear();
}
/**
 * Sets the new animal list vmToAnimalList.
 * 
 * @param vmToAnimalList the new scheduling interval
 */
protected void setSchedulingInterval(	/** a vm to animal list*/
		List<Map<String, Object>> vmToAnimalList) {
	this.vmIdToAnimalLocList = vmToAnimalList;
}

public List<GameTheoryRabbit> getRabbits() {
	return rabbits;
}

public void setRabbits(List<GameTheoryRabbit> rabbits) {
	this.rabbits = rabbits;
}
//The method to write results to external file
	private static void WriteResultsToFile(double[] results){
		//create a file writer
		FileWriter fw;
		try {
	/** Constructs a FileWriter object given a File object.
	Pass true as second parameter to the constructor of FileWriter to instruct the writer to append the data 
	instead of rewriting the file. */
			fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\Simulator1.csv", true); 
			try (PrintWriter pw = new PrintWriter(fw)) {
	//Writes the number of columns, the range of the DataMatrix
	for(int i = 0; i < results.length; i++){
	pw.print(results[i]);
	//to separate the values by comma, when opened in .txt format.
	pw.print(",");
	}
	pw.println();
	//Flush the output to the file
	pw.flush();
	//Close the Print Writer
	pw.close();
	}
	//Close the File Writer
	fw.close();
//Marker for writing to output file.
//	System.out.println("Successfully wrote to the file.");
	} catch (IOException e) {
	}
	}
}
