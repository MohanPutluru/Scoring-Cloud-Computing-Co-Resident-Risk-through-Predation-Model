/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package zerotrust2;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.core.CloudInformationService;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.FutureQueue;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;
import org.cloudbus.cloudsim.examples.power.planetlab.PlanetLabConstants;
import org.cloudbus.cloudsim.power.PowerHost;

import predprey.Animal;
import predprey.Location;
import predprey.Rabbit;

/**
 * PowerDatacenter is a class that enables simulation of power-aware data centers.
 * 
 * <br/>If you are using any algorithms, policies or workload included in the power package please cite
 * the following paper:<br/>
 * 
 * <ul>
 * <li><a href="http://dx.doi.org/10.1002/cpe.1867">Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012</a>
 * </ul>
 * 
 * @author Anton Beloglazov
 * @since CloudSim Toolkit 2.0
 */
public class ZeroTrustDatacenter extends Datacenter {

	/** The datacenter consumed power. */
	private double power;

	/** Indicates if migrations are disabled or not. */
	private boolean disableMigrations;

	/** The last time submitted cloudlets were processed. */
	private double cloudletSubmitted;

	/** The VM migration count. */
	private int migrationCount;
	
	/** The VM migration count. */
	public int timePeriodCount;
	
	/** the zero trust interval count*/
	public int zeroTrustCnt;

	/**
	 * Instantiates a new PowerDatacenter.
	 * 
	 * @param name the datacenter name
	 * @param characteristics the datacenter characteristics
	 * @param schedulingInterval the scheduling interval
	 * @param vmAllocationPolicy the vm provisioner
	 * @param storageList the storage list
	 * @throws Exception the exception
	 */
	public ZeroTrustDatacenter(
			String name,
			DatacenterCharacteristics characteristics,
			VmAllocationPolicy vmAllocationPolicy,
			List<Storage> storageList,
			double schedulingInterval) throws Exception {
		super(name, characteristics, vmAllocationPolicy, storageList, schedulingInterval);

		setPower(0.0);
		setDisableMigrations(false);
		setCloudletSubmitted(-1);
		setMigrationCount(0);
		setTimePeriodCount(0);
	}

	/**
	 * Processes events or services that are available for this PowerDatacenter.
	 * 
	 * @param ev a Sim_event object
	 * @pre ev != null
	 * @post $none
	 */
	@Override
	public void processEvent(SimEvent ev) {
		int srcId = -1;

		switch (ev.getTag()) {
		// Resource characteristics inquiry
			case CloudSimTags.RESOURCE_CHARACTERISTICS:
				srcId = ((Integer) ev.getData()).intValue();
				sendNow(srcId, ev.getTag(), getCharacteristics());
				break;

			// Resource dynamic info inquiry
			case CloudSimTags.RESOURCE_DYNAMICS:
				srcId = ((Integer) ev.getData()).intValue();
				sendNow(srcId, ev.getTag(), 0);
				break;

			case CloudSimTags.RESOURCE_NUM_PE:
				srcId = ((Integer) ev.getData()).intValue();
				int numPE = getCharacteristics().getNumberOfPes();
				sendNow(srcId, ev.getTag(), numPE);
				break;

			case CloudSimTags.RESOURCE_NUM_FREE_PE:
				srcId = ((Integer) ev.getData()).intValue();
				int freePesNumber = getCharacteristics().getNumberOfFreePes();
				sendNow(srcId, ev.getTag(), freePesNumber);
				break;

			// New Cloudlet arrives
			case CloudSimTags.CLOUDLET_SUBMIT:
				processCloudletSubmit(ev, false);
				break;

			// New Cloudlet arrives, but the sender asks for an ack
			case CloudSimTags.CLOUDLET_SUBMIT_ACK:
				processCloudletSubmit(ev, true);
				break;

			// Cancels a previously submitted Cloudlet
			case CloudSimTags.CLOUDLET_CANCEL:
				processCloudlet(ev, CloudSimTags.CLOUDLET_CANCEL);
				break;

			// Pauses a previously submitted Cloudlet
			case CloudSimTags.CLOUDLET_PAUSE:
				processCloudlet(ev, CloudSimTags.CLOUDLET_PAUSE);
				break;

			// Pauses a previously submitted Cloudlet, but the sender
			// asks for an acknowledgement
			case CloudSimTags.CLOUDLET_PAUSE_ACK:
				processCloudlet(ev, CloudSimTags.CLOUDLET_PAUSE_ACK);
				break;

			// Resumes a previously submitted Cloudlet
			case CloudSimTags.CLOUDLET_RESUME:
				processCloudlet(ev, CloudSimTags.CLOUDLET_RESUME);
				break;

			// Resumes a previously submitted Cloudlet, but the sender
			// asks for an acknowledgement
			case CloudSimTags.CLOUDLET_RESUME_ACK:
				processCloudlet(ev, CloudSimTags.CLOUDLET_RESUME_ACK);
				break;

			// Moves a previously submitted Cloudlet to a different resource
			case CloudSimTags.CLOUDLET_MOVE:
				processCloudletMove((int[]) ev.getData(), CloudSimTags.CLOUDLET_MOVE);
				break;

			// Moves a previously submitted Cloudlet to a different resource
			case CloudSimTags.CLOUDLET_MOVE_ACK:
				processCloudletMove((int[]) ev.getData(), CloudSimTags.CLOUDLET_MOVE_ACK);
				break;

			// Checks the status of a Cloudlet
			case CloudSimTags.CLOUDLET_STATUS:
				processCloudletStatus(ev);
				break;

			// Ping packet
			case CloudSimTags.INFOPKT_SUBMIT:
				processPingRequest(ev);
				break;

			case CloudSimTags.VM_CREATE:
				SimEvent event1 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_MIGRATE));
				SimEvent event2 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_MIGRATE_ACK));
				if (!(event1 == null && event2 == null)) {
//					System.out.println("the deffered queue has migrate and " + CloudSim.findFirstDeferred(srcId, new PredicateNotType(CloudSimTags.VM_MIGRATE)) +" Press enter to continue");
//					try{System.in.read();}
//					        catch(Exception e){}
					send(getId(), CloudSim.getMinTimeBetweenEvents()*5, CloudSimTags.VM_CREATE, (Object) ev.getData());
				}else
				processVmCreate(ev, false);
				break;

			case CloudSimTags.VM_CREATE_ACK:
				processVmCreate(ev, true);
				break;

			case CloudSimTags.VM_DESTROY:
				processVmDestroy(ev, false);
				break;

			case CloudSimTags.VM_DESTROY_ACK:
				processVmDestroy(ev, true);
				break;

			case CloudSimTags.VM_MIGRATE:
				processVmMigrate(ev, false);
				break;

			case CloudSimTags.VM_MIGRATE_ACK:
				SimEvent event3 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_DESTROY));
				SimEvent event4 = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_DESTROY_ACK));
				if (!(event3 == null || event4 == null)) {
					send(getId(), CloudSim.getMinTimeBetweenEvents()*5, CloudSimTags.VM_MIGRATE, (Object) ev.getData());
				}else
				processVmMigrate(ev, true);
				break;

			case CloudSimTags.VM_DATA_ADD:
				processDataAdd(ev, false);
				break;

			case CloudSimTags.VM_DATA_ADD_ACK:
				processDataAdd(ev, true);
				break;

			case CloudSimTags.VM_DATA_DEL:
				processDataDelete(ev, false);
				break;

			case CloudSimTags.VM_DATA_DEL_ACK:
				processDataDelete(ev, true);
				break;	

			case CloudSimTags.VM_DATACENTER_EVENT:
				makeHostData();
				matchVms();
				incrementTimePeriodCount();
				incrementZeroTrustCnt();
				System.out.println("The time period count is: " + getTimePeriodCount()+ "\n");
				if(getZeroTrustCnt() == 3) {
					ZeroTrustRunner.getTranslator().simulateOneStep();
					setZeroTrustCnt(0);
					matchVms();
				}
				
				updateCloudletProcessing();
				checkCloudletCompletion();
				break;
				
			// other unknown tags are processed by this method
			default:
				processOtherEvent(ev);
				break;
		}
	}
	@Override
	protected void updateCloudletProcessing() {
		if (getCloudletSubmitted() == -1 || getCloudletSubmitted() == CloudSim.clock()) {
			CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.VM_DATACENTER_EVENT)); // a predicate type based on cloudlet predicate
			schedule(getId(), getSchedulingInterval(), CloudSimTags.VM_DATACENTER_EVENT);
			return;
		}
		double currentTime = CloudSim.clock();

		// if some time passed since last processing
		if (currentTime > getLastProcessTime()) {

			double minTime = updateCloudetProcessingWithoutSchedulingFutureEventsForce();
	//	Code to initiate and execute migrations			
			if (!isDisableMigrations()) {
				List<Map<String, Object>> migrationMap = getVmAllocationPolicy().optimizeAllocation(
						getVmList());
System.out.println("[updateCloudletProcessing] The migration map has " + migrationMap.size());
				if (migrationMap != null) {
					for (Map<String, Object> migrate : migrationMap) {
						Vm vm = (Vm) migrate.get("vm");
						PowerHost targetHost = (PowerHost) migrate.get("host");
						PowerHost oldHost = (PowerHost) vm.getHost();

						if (oldHost == null) {
							Log.formatLine(
									"\n%.2f: Migration of VM #%d to Host #%d is started",
									currentTime,
									vm.getId(),
									targetHost.getId());
						} else {
							Log.formatLine(
									"\n%.2f: Migration of VM #%d from Host #%d to Host #%d is started",
									currentTime,
									vm.getId(),
									oldHost.getId(),
									targetHost.getId());
						}

						targetHost.addMigratingInVm(vm);
//	System.out.println("In the power d/c, the add migrating in produces a map: " + targetHost.getVmsMigratingIn());
						incrementMigrationCount();

						/** VM migration delay = RAM / bandwidth **/
						// we use BW / 2 to model BW available for migration purposes, the other
						// half of BW is for VM communication
						// around 16 seconds for 1024 MB using 1 Gbit/s network
						
					
//						System.out.println(" This portion is about a delay.");
						send(
								getId(),
								vm.getRam() / ((double) targetHost.getBw() / (2 * 8000)),
								CloudSimTags.VM_MIGRATE,
								migrate);
// Marker find the time for the migration completion	
//			System.out.println("The vm: " + vm + " to the target host " + targetHost + " will occur.");
//			System.out.println("The time of the migration into the next host  is " + vm.getRam() / (targetHost.getBw() / (2 * 8000))+ " from now: " + CloudSim.clock());
					}
				}
			}

			// schedules an event to the next time
			if (minTime != Double.MAX_VALUE) {
				CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.VM_DATACENTER_EVENT));
// Marker for the schedule of the next event at the scheduling interval
				System.out.println("The next scheduling of vm_dc_evt is at " + (currentTime+getSchedulingInterval()));
				send(getId(), getSchedulingInterval(), CloudSimTags.VM_DATACENTER_EVENT);
			}

			setLastProcessTime(currentTime);
		}
	}

	/**
	 * Update cloudet processing without scheduling future events.
	 * 
	 * @return the double
         * @see #updateCloudetProcessingWithoutSchedulingFutureEventsForce() 
         * @todo There is an inconsistence in the return value of this
         * method with return value of similar methods
         * such as {@link #updateCloudetProcessingWithoutSchedulingFutureEventsForce()},
         * that returns {@link Double#MAX_VALUE} by default.
         * The current method returns 0 by default.
	 */
	protected double updateCloudetProcessingWithoutSchedulingFutureEvents() {
		if (CloudSim.clock() > getLastProcessTime()) {
			return updateCloudetProcessingWithoutSchedulingFutureEventsForce();
		}
		return 0;
	}

	/**
	 * Update cloudet processing without scheduling future events.
	 * 
	 * @return expected time of completion of the next cloudlet in all VMs of all hosts or
	 *         {@link Double#MAX_VALUE} if there is no future events expected in this host
	 */
	protected double updateCloudetProcessingWithoutSchedulingFutureEventsForce() {
		double currentTime = CloudSim.clock();
		double minTime = Double.MAX_VALUE;
		double timeDiff = currentTime - getLastProcessTime();
		double timeFrameDatacenterEnergy = 0.0;
		final double[] DataMatrix = new double[7+ZeroTrustConstants.HOST_WIDTH*ZeroTrustConstants.HOST_HEIGHT];
		DataMatrix[0]=currentTime;
		DataMatrix[1]=getVmList().size();
		DataMatrix[2]=getMigrationCount();
		DataMatrix[3]=ZeroTrustRunner.getTranslator().getVmIdToAnimalLocList().size();
		DataMatrix[4]=ZeroTrustRunner.getTranslator().getRabbits().size();
		DataMatrix[5]=ZeroTrustRunner.getTranslator().getFoxes().size();
		int numCrtVms = 0;
		for(Vm vm: getVmList()) {
			if(vm.getCloudletScheduler().getCloudletStatus(vm.getId()) == Cloudlet.INEXEC) {
				numCrtVms++;
				if(numCrtVms > 1600) {
					System.out.println("[updateCloudetProcessingWithoutSchedulingFutureEventsForce()], vms in exec =  " + numCrtVms);
					try{System.in.read();}
				    catch(Exception e){}
				}
				}
		}
		DataMatrix[6]=numCrtVms;
		
		Log.printLine("\n\n--------------------------------------------------------------\n\n");
		Log.formatLine("New resource usage for the time frame starting at %.2f:", currentTime);

		for (PowerHost host : this.<PowerHost> getHostList()) {
			double time = host.updateVmsProcessing(currentTime); // inform VMs to update processing
			if (time < minTime) {
				minTime = time;
			}

			Log.formatLine(
					"%.2f: [Host #%d] utilization is %.2f%%",
					currentTime,
					host.getId(),
					host.getUtilizationOfCpu() * 100);
		}

		if (timeDiff > 0) {
			Log.formatLine(
					"\nEnergy consumption for the last time frame from %.2f to %.2f:",
					getLastProcessTime(),
					currentTime);

			for (PowerHost host : this.<PowerHost> getHostList()) {
				double previousUtilizationOfCpu = host.getPreviousUtilizationOfCpu();
				double utilizationOfCpu = host.getUtilizationOfCpu();
				double timeFrameHostEnergy = host.getEnergyLinearInterpolation(
						previousUtilizationOfCpu,
						utilizationOfCpu,
						timeDiff);
				timeFrameDatacenterEnergy += timeFrameHostEnergy;

				Log.printLine();
				Log.formatLine(
						"%.2f: [Host #%d] utilization at %.2f was %.2f%%, now is %.2f%%",
						currentTime,
						host.getId(),
						getLastProcessTime(),
						previousUtilizationOfCpu * 100,
						utilizationOfCpu * 100);
				Log.formatLine(
						"%.2f: [Host #%d] energy is %.2f W*sec",
						currentTime,
						host.getId(),
						timeFrameHostEnergy);
				DataMatrix[getHostList().indexOf(host)+7]=timeFrameHostEnergy;
//				DataMatrix[7+ZeroTrustConstants.HOST_WIDTH*ZeroTrustConstants.HOST_HEIGHT] = getTimePeriodCount();
			}

			Log.formatLine(
					"\n%.2f: Data center's energy is %.2f W*sec\n",
					currentTime,
					timeFrameDatacenterEnergy);
		}

		setPower(getPower() + timeFrameDatacenterEnergy);

		checkCloudletCompletion();

		/** Remove completed VMs **/
		for (PowerHost host : this.<PowerHost> getHostList()) {
			for (Vm vm : host.getCompletedVms()) {
				System.out.println("vm " + vm.getId() + " has a cloudlet status " + vm.getCloudletScheduler().getCloudletStatus(vm.getId()));
				System.out.println("On host: " + host.getId()+ "A vm is complete. Press enter to continue");
				System.out.println("The cloudlets are on : " + vm.getCloudletScheduler());
				try{System.in.read();}
			    catch(Exception e){}
				getVmAllocationPolicy().deallocateHostForVm(vm);
				getVmList().remove(vm);
				Log.printLine("VM #" + vm.getId() + " has been deallocated from host #" + host.getId());
			}
		}

		Log.printLine();
		//Use of the write method to append the row to the file
		WriteResultsToFile(DataMatrix);

		setLastProcessTime(currentTime);
		return minTime;
	}
	/**
	 * Verifies if some cloudlet inside this PowerDatacenter already finished. If yes, send it to
	 * the User/Broker
	 * 
	 * @pre $none
	 * @post $none
	 */
	@Override
	protected void checkCloudletCompletion() {
		List<? extends Host> list = getVmAllocationPolicy().getHostList();
//		System.out.println("In cloudlet completion:");
//		pauseTest();
			for (int i = 0; i < list.size(); i++) {
			Host host = list.get(i);
			for (Vm vm : host.getVmList()) {
				while (vm.getCloudletScheduler().isFinishedCloudlets()) {
					Cloudlet cl = vm.getCloudletScheduler().getNextFinishedCloudlet();					
					if (cl != null) {
						System.out.println("Cloudlet for vm: " +cl.getVmId() + " is complete.");
pauseTest();
						sendNow(cl.getUserId(), CloudSimTags.CLOUDLET_RETURN, cl);
					}
				}
			}
		}
	}
	
	void matchVms(){
		List<Map<String, Object>> vmIdToAnimalLocList = ZeroTrustRunner.getTranslator().getVmIdToAnimalLocList();
		int numActVms= vmIdToAnimalLocList.size();
		int numCrtVms = 0;
		List<Vm> pausedVms = new ArrayList<Vm>();
		List<Vm> inexecVms = new ArrayList<Vm>();
		for(Vm vm : getVmList()) {
			if(vm.getCloudletScheduler().getCloudletStatus(vm.getId()) == Cloudlet.INEXEC) {
				numCrtVms++;
				inexecVms.add(vm);
			}else {
				pausedVms.add(vm);
			}
		}
//		System.out.println("numActVms " + numActVms);
//		System.out.println("inexecVms size: "+ inexecVms.size());
//		System.out.println("pausedVms size: "+ pausedVms.size() );
//		System.out.println("matchVms() Press enter to continue");
//		try{System.in.read();}
//        catch(Exception e){}
			int ofstNumVms =numActVms-numCrtVms;
			if(ofstNumVms>0) {
				while (ofstNumVms > 0){
				int randomNumber = (int) (Math.random()*(pausedVms.size()-1));
				if (pausedVms.size()==randomNumber&&pausedVms.size()!=0) {
					randomNumber=randomNumber-1;
				}
				Vm vmSelected = pausedVms.get(randomNumber);
				int[] data = new int[3];
				data[0] = vmSelected.getId();
				data[1] = vmSelected.getUserId();
				data[2] = vmSelected.getId();
				sendNow(getId(), CloudSimTags.CLOUDLET_RESUME, data);
				ofstNumVms--;
				}
			}else if(ofstNumVms<0) {
				while (ofstNumVms < 0){
				int randomNumber = (int) (Math.random()*(inexecVms.size()-1)) + 1;
				Vm vmSelected = inexecVms.get(randomNumber);
				int[] data = new int[3];
				data[0] = vmSelected.getId();
				data[1] = vmSelected.getUserId();
				data[2] = vmSelected.getId();
				sendNow(getId(), CloudSimTags.CLOUDLET_PAUSE, data);
				ofstNumVms++;
				}
			}
	}
	
	@Override
	protected void processVmMigrate(SimEvent ev, boolean ack) {
		updateCloudetProcessingWithoutSchedulingFutureEvents();
		super.processVmMigrate(ev, ack);
		SimEvent event = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.VM_MIGRATE));
		if (event == null || event.eventTime() > CloudSim.clock()) {
			updateCloudetProcessingWithoutSchedulingFutureEventsForce();
		}
	}
	/**
	 * process cloudlet submit in this class includes code to set the vm cloudlet into paused when it is submitted
	 * it will be sent as an event in this condition and it's transfer to inexec depends on the vms active
	 * the helper is adjusted to use this datacenter
	 */
	@Override
	protected void processCloudletSubmit(SimEvent ev, boolean ack) {
		super.processCloudletSubmit(ev, ack);
//		Sets the cloudlet into pause when it is submitted for the vm.	
		Cloudlet cl = (Cloudlet) ev.getData();
		int vmId = cl.getVmId();
		for(Vm vm: getVmList()) {
			if (vm.getId()==vmId) {
						vm.getCloudletScheduler().cloudletPause(vm.getId());
					}
			
		}
		setCloudletSubmitted(CloudSim.clock());
		SimEvent event = CloudSim.findFirstDeferred(getId(), new PredicateType(CloudSimTags.CLOUDLET_SUBMIT));
		if (event == null || event.eventTime() > CloudSim.clock()) {
			matchVms();
		}
	}

	/**
	 * Gets the power.
	 * 
	 * @return the power
	 */
	public double getPower() {
		return power;
	}

	/**
	 * Sets the power.
	 * 
	 * @param power the new power
	 */
	protected void setPower(double power) {
		this.power = power;
	}

	/**
	 * Checks if PowerDatacenter is in migration.
	 * 
	 * @return true, if PowerDatacenter is in migration; false otherwise
	 */
	protected boolean isInMigration() {
		boolean result = false;
		for (Vm vm : getVmList()) {
			if (vm.isInMigration()) {
				result = true;
				break;
			}
		}
		return result;
	}

	/**
	 * Checks if migrations are disabled.
	 * 
	 * @return true, if  migrations are disable; false otherwise
	 */
	public boolean isDisableMigrations() {
		return disableMigrations;
	}

	/**
	 * Disable or enable migrations.
	 * 
	 * @param disableMigrations true to disable migrations; false to enable
	 */
	public void setDisableMigrations(boolean disableMigrations) {
		this.disableMigrations = disableMigrations;
	}

	/**
	 * Checks if is cloudlet submited.
	 * 
	 * @return true, if is cloudlet submited
	 */
	protected double getCloudletSubmitted() {
		return cloudletSubmitted;
	}

	/**
	 * Sets the cloudlet submitted.
	 * 
	 * @param cloudletSubmitted the new cloudlet submited
	 */
	protected void setCloudletSubmitted(double cloudletSubmitted) {
		this.cloudletSubmitted = cloudletSubmitted;
	}

	/**
	 * Gets the migration count.
	 * 
	 * @return the migration count
	 */
	public int getMigrationCount() {
		return migrationCount;
	}

	/**
	 * Sets the migration count.
	 * 
	 * @param migrationCount the new migration count
	 */
	protected void setMigrationCount(int migrationCount) {
		this.migrationCount = migrationCount;
	}

	/**
	 * Increment migration count.
	 */
	protected void incrementMigrationCount() {
		setMigrationCount(getMigrationCount() + 1);
	}
	/**
	 * Gets the time period count.
	 * 
	 * @return the time period count
	 */
	public int getTimePeriodCount() {
		return timePeriodCount;
	}
	/**
	 * Sets the time period count.
	 * 
	 * @param timePeriodCount the new migration count
	 */
	private void setTimePeriodCount(int timePeriodCount) {
		this.timePeriodCount = timePeriodCount;
		}
	
	/**
	 * Increment migration count.
	 */
	protected void incrementZeroTrustCnt() {
		setZeroTrustCnt(getZeroTrustCnt() + 1);
	}
	/**
	 * @return the zeroTrustCnt
	 */
	public int getZeroTrustCnt() {
		return zeroTrustCnt;
	}

	/**
	 * @param zeroTrustCnt the zeroTrustCnt to set
	 */
	public void setZeroTrustCnt(int zeroTrustCnt) {
		this.zeroTrustCnt = zeroTrustCnt;
	}

	/**
	 * Increment time period count.
	 */
	protected void incrementTimePeriodCount() {
		setTimePeriodCount(getTimePeriodCount() + 1);
	}
	
	// The method to write results to external file
		private static void WriteResultsToFile(double[] results)
	{
	//create a file writer
	FileWriter fw;
	try {
	/** Constructs a FileWriter object given a File object.
	If the second argument is true, then bytes will be written to the end of the file rather than the beginning.  
	Pass true as second parameter to the constructor of FileWriter to instruct the writer to append the data instead of rewriting the file. */
	fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\ZeroTrust.csv", true); 
	try (PrintWriter pw = new PrintWriter(fw)) {
	for(int i = 0; i < results.length; i++){
	pw.print(results[i]);
	//to separate the values by comma, when opened in .txt format.
	pw.print(",");
	}
	pw.println();
	//Flush the output to the file
	pw.flush();
	//Close the Print Writer
	pw.close();
	}
	//Close the File Writer
	fw.close();
//Marker for writing to output file.
//	System.out.println("Successfully wrote to the file.");
	} catch (IOException e) {
	}
	}
		
		public void makeHostData() {
			final double[] DataMatrix = new double[1+ZeroTrustConstants.HOST_WIDTH*ZeroTrustConstants.HOST_HEIGHT];
			DataMatrix[0]= CloudSim.clock();
			for (Host host: getHostList()) {
				int vmNumber = host.getVmList().size();
				DataMatrix[1+getHostList().indexOf(host)]=vmNumber;
			}
			WriteHostDataToFile(DataMatrix);
		}

	private static void WriteHostDataToFile(double[] hostData){
		FileWriter fw;
		try {
		fw = new FileWriter("C:\\Users\\HP_PC\\Documents\\ZeroTrustHosts.csv", true); 
		try (PrintWriter pw = new PrintWriter(fw)) {
		for(int i = 0; i < hostData.length; i++){
		pw.print(hostData[i]);
		pw.print(",");
		}
		pw.println();
		pw.flush();
		pw.close();
		}
		fw.close();
		} //endtry
		catch (IOException e) {}
		}

}
