package zerotrust2;

import java.io.IOException;

/**
 * A simulation of a heterogeneous power aware data center that applies the Inter Quartile Range
 * (IQR) VM allocation policy and Minimum Utilization (MU) VM selection policy.
 * 

 */
public class ZeroTrust {

	/**
	 * The main method.
	 * 
	 * @param args the arguments
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void main(String[] args) throws IOException {
		boolean enableOutput = true;
		boolean outputToFile = false;
//		String inputFolder = IqrMu.class.getClassLoader().getResource("workload/planetlab").getPath();
		String inputFolder = "examples";
		String outputFolder = "output";
		String workload = "2_GameTheory1Data"; // PlanetLab workload
		String vmAllocationPolicy = "iqr"; // Inter Quartile Range (IQR) VM allocation policy
		String vmSelectionPolicy = "zerotrust"; // Minimum Utilization (MU) VM selection policy
		String parameter = "1.5"; // the safety parameter of the IQR policy

		new ZeroTrustRunner(
				enableOutput,
				outputToFile,
				inputFolder,
				outputFolder,
				workload,
				vmAllocationPolicy,
				vmSelectionPolicy,
				parameter);
	}

}
