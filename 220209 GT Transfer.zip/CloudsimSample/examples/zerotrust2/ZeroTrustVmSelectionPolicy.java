/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package zerotrust2;

import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.power.*;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.VmStateHistoryEntry;
import org.cloudbus.cloudsim.util.ExecutionTimeMeasurer;


/**
  */
public class ZeroTrustVmSelectionPolicy extends PowerVmSelectionPolicy {
	/* (non-Javadoc)
	 * @see
	 * org.cloudbus.cloudsim.experiments.power.PowerVmSelectionPolicy#getVmsToMigrate(org.cloudbus
	 * .cloudsim.power.PowerHost) */
	
	
	@Override
	public Vm getVmToMigrate(PowerHost host) {
		List<PowerVm> migratableVms = getMigratableVms(host);
		if (migratableVms.isEmpty()) {
			return null;
		}
		double maxTime = 0;
		double vm1Time = 0;
		double vm2Time = 0;
		Vm vmToMigrate = null;
		Vm vm1 = null;	
		Vm vm2 = null;
			for (Vm vm : migratableVms) {
			if (vm.getCloudletScheduler().getCloudletStatus(vm.getId())==Cloudlet.PAUSED) {
				vmToMigrate = vm;
			}
		if (!vm.getStateHistory().isEmpty()&& !vm.isInMigration()) {
					int i=2;
					VmStateHistoryEntry curState = vm.getStateHistory().get(vm.getStateHistory().size()-1);
					while(i<vm.getStateHistory().size()-1) {//scan through previous states to find when migrated
						VmStateHistoryEntry previousState = vm.getStateHistory().get(vm.getStateHistory().size() - i);
					if (previousState.isInMigration()==true) {//if it finds a previous migration time exceeding threshhold
						System.out.println("vm " +vm.getId() + " on host " + vm.getHost().getId() +" migrated "+  (curState.getTime()-previousState.getTime()) +" secs ago.");
						if (curState.getTime()-previousState.getTime()>ZeroTrustConstants.SCHEDULING_INTERVAL && vm1 == null) {
							vm1Time = curState.getTime()-previousState.getTime();
							vm1 = vm;		
						}else if (curState.getTime()-previousState.getTime()>ZeroTrustConstants.SCHEDULING_INTERVAL && vm2 != null) {
							vm2 = vm;
							vm2Time = curState.getTime()-previousState.getTime();
						}
						break;
					}
				i++;
				}if(vm2!=null) {
					if(vm1Time-vm2Time>= ZeroTrustConstants.SCHEDULING_INTERVAL*2 && maxTime < Math.abs(vm1Time-vm2Time)) {
						vmToMigrate = vm1;
						maxTime = Math.abs(vm1Time-vm2Time);
						}else if (vm2Time-vm1Time>= ZeroTrustConstants.SCHEDULING_INTERVAL*2 && maxTime < Math.abs(vm1Time-vm2Time)) {
						vmToMigrate = vm2;
						vm1=vm2;
						maxTime = Math.abs(vm1Time-vm2Time);
					}
				}
			}
		}
		return vmToMigrate;
	}
	/**
	 * Gets the migratable vms.
	 * 
	 * @param host the host
	 * @return the migratable vms
	 */
	@Override
	protected List<PowerVm> getMigratableVms(PowerHost host) {
		List<PowerVm> migratableVms = new ArrayList<PowerVm>();
		int pausedCnt = 0;
		for (PowerVm vm : host.<PowerVm> getVmList()) {
			if (vm.getCloudletScheduler().getCloudletStatus(vm.getId())==Cloudlet.PAUSED) {pausedCnt++;}
		if (!vm.isInMigration()) {
				migratableVms.add(vm);
			}
		if (vm.getCloudletScheduler().getCloudletStatus(vm.getId())==Cloudlet.PAUSED && pausedCnt>1){
			migratableVms.remove(vm);
		}
		}
	return migratableVms;
	}

}
